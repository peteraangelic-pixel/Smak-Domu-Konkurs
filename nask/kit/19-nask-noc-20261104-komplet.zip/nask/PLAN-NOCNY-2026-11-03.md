# PLAN NOCNY 3/4.11.2026 — hack.cert.pl (edycja 11/2026)

## Zrobione tej nocy (pasywnie, w granicach regulaminu)

1. **Rekonesans JS**: 3 GET-y (strony główne) + 46 publicznych bundli Next.js
   (zglos-dezinformacje, oad, www.nask.pl) — 1 req/s, log pełny.
   Surowiec: `recon/evidence-20261103/` (3.9 MB).
2. **`rust/endminer`** — narzędzie offline (Rust+Rayon): endpointy, ID-templaity,
   parametry, sekrety (z klasyfikatorem §8 — excluded flaguje z góry, żeby nie
   wysyłać odrzuceń), 8/8 testów PASS. Na 2 rdzeniach sandboxa: 590 obserwacji/71 ms;
   na Ryzen 9 5950X pełny katalog zejdzie w sekundy.
3. **Wynik rekonesansu** → `recon/MAPA-ENDPOINTOW-2026-11-03.md`:
   - zglos-dezinformacje: **`/api/sendForm`** (jedyna API) — cel hipotez upload/mass assignment,
   - oad.nask.pl: **publiczny embed PowerBI (autoAuth=true)** — sprawdzić pasywnie, co pokazuje,
   - www.nask.pl: portal treściowy, nisko.
4. **Rank pieniędzy + kalibracja** → `IDEE-ZAROBEK-2026-11-03.md`.

## Odpowiedź na pytanie „skąd moc obliczeniowa”

- **Ryzen 9 5950X (16C/64GB) > GitHub Actions** (free runner = 2 vCPU/7GB) — do
  Rayon/Rust używaj lokalnie, Actions zostaw na CI/testy i joby zaplanowane lekkie.
- Ale ta edycja **nie potrzebuje mocy** — potrzebuje RĘCZNEJ pracy w sesjach.
  Moc = kończenie minera po 26 hostach (minuty), nie dłuższe skany (§8 i tak je zabija).

## Kolejność na kolejne noce (5.11–29.11)

1. **(user, 15 min)** Konto na hack.cert.pl → przeczytać widoki programów w panelu
   (formularz zgłoszenia — tam jest kolejność i pola; szkielet raportu: Drive 10-ZALACZNIK).
2. **(user, 30 min)** Konta własne: mSzyfr ×2, moje.cert.pl, mwdb.cert.pl.
3. **(user w DevTools + agent przygotowuje instrukcje)** Seria ręcznych testów
   z `IDEE-ZAROBEK` §1–3 — każda hipoteza ma warunek odrzucenia; trafienie = stop,
   Potwierdzenie 2×, draft raportu, submit (pierwszeństwo!).
4. **(agent, WYKONANE w nocy 3/4.11)** Miner na hack.cert.pl (PEŁNA mapa /api/v1 → H1–H7),
   moje.cert.pl (Django, nisko) i mSzyfr (Element Web; bundle tylko z przeglądarki —
   catch-all 200). Szczegóły: recon/MAPA-ENDPOINTOW-2026-11-03.md (dodatek).
   Zostały: n6portal, science, 116sos, pllum, dyzurnet, dns.pl (tylko publiczne), secure.edu.pl, bezpiecznewybory.pl.
5. **(agent)** Po każdym znalezisku: pełny szkielet raportu (PoC + kroki + wpływ + złagodzenie).

## Guardy (przestrzegane bez wyjątków)

- automaty ≤ **5 req/s** (u nas: 1 req/s w rekonesansie, narzędzia offline bez sieci),
- tylko **własne/testowe** konta; zero cudzych i domenowych,
- zero DoS/spamu/SE/phishingu; dane osobowe → przerwać natychmiast,
- dyskrecja do poprawki; publikacja = nigdy przed poprawką i zgodą programu,
- panel.dns.pl/partner.dns.pl poza zakresem (niepotwierdzone) — nie dotykać,
- incydent.cert.pl — bez fikcyjnych zgłoszeń.

## Granice mojej roli (bez zmian)

Nie zakładam kont, nie eksploatuję, nie wysyłam zgłoszeń. Dostarczam: mapy,
kandydatów z warunkami odrzucenia, instrukcje PoC krok-po-kroku, drafty raportów,
narzędzia offline, pilnuję limitów.


## UPDATE 4.11 (rano) — po przeglądzie 6 nocnych sesji
Bilans nocy: ~2500+ żądań, 0 potwierdzonych podatności — anonimowa powierzchnia zamknięta.
Pełna synteza: `PRZEGLAD-GALEZI-2026-11-04.md`. Wniosek operacyjny: bez kont usera nie
ma dalszego postępu; priorytet #1 = hack.cert.pl (mapa /api/v1 + payout), #2 = HIVE,
#3 = mSzyfr. mwdb zamknięty (2.20.0). N6 zmapowany (OIDC/MFA/API-key). Do mapowania:
dyzurnet.pl, dns.pl (chunki JS) — moja robota offline.
