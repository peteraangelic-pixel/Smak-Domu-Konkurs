//! endminer-lib — silnik ekstrakcji offline (bez dostępu do sieci).
//!
//! Wejście: zapisane lokalnie pliki (HTML/JS/JSON/source-map), tak jak je
//! zapisuje przeglądarka lub curl. Wyjście: listy obserwacji z klasyfikacją
//! pod §8 regulaminu hack.cert.pl (co NADAJE SIĘ na hipotezę zgłoszenia,
//! a co jest a priori WYKLUCZONE — żeby nie marnować zgłoszeń).

use rayon::prelude::*;
use regex::Regex;
use serde::Serialize;
use std::collections::HashSet;
use std::path::Path;

/// Klasyfikacja pod regulamin (§8 = wykluczenia, nie płacą).
#[derive(Serialize, Clone, Copy, Debug, PartialEq, Eq)]
pub enum Verdict {
    /// Obiecująca hipoteza: endpoint wewnętrzny/admin, ID w ścieżce (IDOR?),
    /// sekret do zweryfikowania ręcznie, API do dalszej mapy.
    Candidate,
    /// Jawne wykluczenie z §8 — NIE zgłaszać (np. wersje/stack trace, assety).
    Excluded,
    /// Neutralna obserwacja (mapa aplikacji).
    Info,
}

#[derive(Serialize, Clone, Debug)]
pub struct Finding {
    pub file: String,
    pub kind: &'static str,
    pub value: String,
    pub context: String,
    pub verdict: Verdict,
    /// Krótkie uzasadnienie po polsku, z odniesieniem do regulaminu gdy wykluczone.
    pub reason: &'static str,
}

const ASSET_EXT: [&str; 12] = [
    ".css", ".js", ".png", ".jpg", ".jpeg", ".svg", ".gif", ".ico", ".woff", ".woff2", ".ttf",
    ".webp",
];

fn looks_like_asset(p: &str) -> bool {
    let low = p.to_lowercase();
    ASSET_EXT.iter().any(|e| low.ends_with(e))
        || low.starts_with("/_next/static/chunks")
        || low.starts_with("/_next/static/css")
        || low.starts_with("/_next/static/media")
}

fn snippet(hay: &str, start: usize) -> String {
    let from = start.saturating_sub(60);
    let to = (start + 120).min(hay.len());
    // bezpieczne cięcie po granicy znaku
    let from = hay.floor_char_boundary(from);
    let to = hay.floor_char_boundary(to);
    hay[from..to].replace('\n', " ").trim().to_string()
}

/// Główna analiza jednego pliku (treść już wczytana jako string).
pub fn analyze(file_label: &str, hay: &str) -> Vec<Finding> {
    let mut out: Vec<Finding> = Vec::new();
    let mut seen: HashSet<(String, String)> = HashSet::new();

    let mut push = |kind: &'static str,
                    value: String,
                    context: String,
                    verdict: Verdict,
                    reason: &'static str,
                    out: &mut Vec<Finding>,
                    seen: &mut HashSet<(String, String)>| {
        if seen.insert((kind.to_string(), value.clone())) {
            out.push(Finding { file: file_label.to_string(), kind, value, context, verdict, reason });
        }
    };

    // 1) Ścieżki względne w cudzysłowach / backtickach.
    let re_path = Regex::new(
        r#"["'`](/[A-Za-z0-9_@%\-.\[\]/{}$]{2,120})["'`]"#,
    )
    .unwrap();
    for m in re_path.captures_iter(hay) {
        let p = &m[1];
        if looks_like_asset(p) {
            continue;
        }
        let ctx = snippet(hay, m.get(1).unwrap().start());
        if p.contains("${") || p.contains('{') {
            push("id_template", p.to_string(), ctx, Verdict::Candidate,
                 "ścieżka z placeholderem ID — hipoteza IDOR/BAC (do ręcznej weryfikacji na WŁASNYM koncie)",
                 &mut out, &mut seen);
        } else if p.contains("admin") || p.contains("internal") || p.contains("private")
            || p.contains("debug") || p.contains("actuator")
        {
            push("sensitive_path", p.to_string(), ctx, Verdict::Candidate,
                 "ścieżka o nazwie admin/internal/debug — sprawdzić ręcznie, czy odpowiada i czy jest chroniona",
                 &mut out, &mut seen);
        } else {
            push("path", p.to_string(), ctx, Verdict::Info,
                 "ścieżka API/aplikacji z kodu klienta — buduje mapę przepływu",
                 &mut out, &mut seen);
        }
    }

    // 2) Pełne URL-e.
    let re_url = Regex::new(r#"https?://[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%\-]{4,300}"#).unwrap();
    for m in re_url.find_iter(hay) {
        let u = m.as_str().trim_end_matches(['"', '\'', '`', ')', ']', ',']);
        let ctx = snippet(hay, m.start());
        // śledzenie ścieżek do zasobów statycznych = zwykły szum
        if looks_like_asset(u.split(['?', '#']).next().unwrap_or("")) && !u.contains("/_next/data") {
            continue;
        }
        push("url", u.to_string(), ctx, Verdict::Info,
             "adres URL w kodzie klienta (mapa hostów/API zależnych)",
             &mut out, &mut seen);
    }

    // 3) Nazwy parametrów z URL-i i template'ów (do testów walidacji).
    let re_param = Regex::new(r#"[?&]([a-zA-Z_][a-zA-Z0-9_]{1,30})="#).unwrap();
    for m in re_param.captures_iter(hay) {
        push("param", m[1].to_string(), snippet(hay, m.get(1).unwrap().start()),
             Verdict::Info, "nazwa parametru — wejście do ręcznych testów walidacji",
             &mut out, &mut seen);
    }

    // 4) UUID (potencjalne identyfikatory zasobów).
    let re_uuid =
        Regex::new(r#"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"#)
            .unwrap();
    for m in re_uuid.find_iter(hay) {
        push("uuid", m.as_str().to_string(), snippet(hay, m.start()), Verdict::Info,
             "UUID w kodzie klienta (budowanie obrazu identyfikatorów)",
             &mut out, &mut seen);
    }

    // 5) Sekrety / klucze. UWAGA regulaminu: sam fakt wycieku klucza bez
    //    wykazanego nadużycia jest WYKLUCZONY (§8: "klucze API bez nadużycia").
    let re_secret = Regex::new(
        r#"(?:AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z_\-]{35}|github_pat_[0-9a-zA-Z_]{20,}|eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)"#,
    )
    .unwrap();
    for m in re_secret.find_iter(hay) {
        let v = m.as_str();
        let is_jwtish = v.starts_with("eyJ");
        push("secret_like", v.to_string(), snippet(hay, m.start()),
             Verdict::Excluded,
             if is_jwtish {
                 "szablon JWT/dummy z kodu klienta — §8: nagłówki/tokeny bez wpływu NIE są zgłaszalne; używać tylko do zrozumienia formatu"
             } else {
                 "sekret w kodzie klienta — sam w sobie §8 (bez nadużycia); ZANIM cokolwiek: zgłosić opiekunowi programu przez formularz, NIE używać klucza"
             },
             &mut out, &mut seen);
    }

    // 6) Komentarze deweloperskie.
    let re_comment = Regex::new(
        r#"//\s*(TODO|FIXME|BUG|HACK|XXX|SECRET|PASSWORD|DEBUG)[^\n]{0,200}"#,
    )
    .unwrap();
    for m in re_comment.find_iter(hay) {
        push("comment", m.as_str().trim().to_string(), snippet(hay, m.start()),
             Verdict::Info, "komentarz deweloperski — kontekst dla człowieka",
             &mut out, &mut seen);
    }

    // 7) Wersje bibliotek / stack trace → jawnie §8, żeby scanner nie mylił.
    let re_ver = Regex::new(r#"(?:version|VERSION)["':=\s]+["']?(\d+\.\d+\.\d+[^"'\s]*)["']?"#)
        .unwrap();
    for m in re_ver.captures_iter(hay) {
        push("version", m[1].to_string(), snippet(hay, m.get(1).unwrap().start()),
             Verdict::Excluded,
             "numer wersji — §8: stack trace/numery wersji same w sobie wykluczone (znane CVE też wymagają PoC)",
             &mut out, &mut seen);
    }

    out
}

/// Analiza równoległa (Rayon) wielu plików z dysku.
pub fn analyze_paths<P: AsRef<Path>>(paths: &[P]) -> Vec<Finding> {
    let file_paths: Vec<_> = paths
        .iter()
        .flat_map(|p| walkdir::WalkDir::new(p).into_iter().filter_map(|e| e.ok()))
        .filter(|e| e.file_type().is_file())
        .filter(|e| {
            e.path()
                .extension()
                .and_then(|x| x.to_str())
                .map(|x| matches!(x, "js" | "html" | "json" | "map" | "txt" | "css"))
                .unwrap_or(false)
        })
        .map(|e| e.path().to_path_buf())
        .collect();

    file_paths
        .par_iter()
        .flat_map_iter(|p| {
            let label = p.display().to_string();
            match std::fs::read_to_string(p) {
                Ok(text) => analyze(&label, &text),
                Err(_) => Vec::new(), // binarne/nietekstowe pomijamy
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wykrywa_sciezke_api() {
        let f = analyze("t.js", r#"fetch("/api/v1/reports")"#);
        assert!(f.iter().any(|x| x.kind == "path" && x.value == "/api/v1/reports"));
    }

    #[test]
    fn id_template_jest_kandydatem() {
        let f = analyze("t.js", r#"const url = `/api/v1/users/${userId}/reports`;"#);
        let hit = f.iter().find(|x| x.kind == "id_template").expect("brak id_template");
        assert_eq!(hit.verdict, Verdict::Candidate);
    }

    #[test]
    fn assety_next_ignorowane() {
        let f = analyze("t.js", r#"src="/_next/static/chunks/abc-def.js""#);
        assert!(f.iter().all(|x| x.value != "/_next/static/chunks/abc-def.js"));
    }

    #[test]
    fn sekret_jest_wykluczony_a_nie_kandydatem() {
        let f = analyze("t.js", "key = \"AKIAIOSFODNN7EXAMPLEQ\";"); // 20 znaków po AKIA
        let hit = f.iter().find(|x| x.kind == "secret_like").expect("brak sekretu");
        assert_eq!(hit.verdict, Verdict::Excluded);
    }

    #[test]
    fn wersja_wykluczona_zgodnie_z_8() {
        let f = analyze("t.js", r#"version: "3.2.1""#);
        let hit = f.iter().find(|x| x.kind == "version").expect("brak wersji");
        assert_eq!(hit.verdict, Verdict::Excluded);
    }

    #[test]
    fn uuid_info() {
        let f = analyze("t.js", "id: \"550e8400-e29b-41d4-a716-446655440000\"");
        assert!(f.iter().any(|x| x.kind == "uuid"));
    }

    #[test]
    fn admin_path_kandydat() {
        let f = analyze("t.js", r#"link: "/admin-panel/overview""#);
        let hit = f.iter().find(|x| x.kind == "sensitive_path").expect("brak");
        assert_eq!(hit.verdict, Verdict::Candidate);
    }

    #[test]
    fn parametr_wykryty() {
        let f = analyze("t.js", r#""https://x.pl/api?a=1&report_id=7""#);
        assert!(f.iter().any(|x| x.kind == "param" && x.value == "report_id"));
    }
}
