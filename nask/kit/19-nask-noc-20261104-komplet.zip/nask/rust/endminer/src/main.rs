//! endminer CLI — offline endpoint/secret/ID miner (Rust + Rayon).
//!
//! UŻYCIE ZGODNE Z REGULAMINEM hack.cert.pl:
//!  * narzędzie NIE ma dostępu do sieci — analizuje wyłącznie pliki zapisane
//!    lokalnie (np. przez przeglądarkę „Zapisz jako" albo curl),
//!  * wyniki traktuj jako HIPOTEZY do ręcznej weryfikacji na własnych
//!    kontach/testowych; automaty przeciwko infrastrukturze ≤ 5 req/s,
//!  * wszystko oznaczone Excluded odpowiada wykluczeniom §8 — nie wysyłaj
//!    tego do zgłoszeń.

use endminer_lib::{analyze_paths, Verdict};
use std::collections::BTreeMap;
use std::io::Write;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("użycie: endminer <PLIK|KATALOG>... [--out wynik.jsonl] [--summary]");
        eprintln!("        analiza OFFLINE zapisanych plików (html/js/json/map). Zero sieci.");
        std::process::exit(1);
    }
    let mut paths = Vec::new();
    let mut out = "endminer-wynik.jsonl".to_string();
    let mut summary = false;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--out" => {
                i += 1;
                out = args.get(i).cloned().unwrap_or(out);
            }
            "--summary" => summary = true,
            p => paths.push(p.to_string()),
        }
        i += 1;
    }

    let t0 = std::time::Instant::now();
    let findings = analyze_paths(&paths);
    let elapsed = t0.elapsed();

    let mut w = std::io::BufWriter::new(std::fs::File::create(&out).expect("nie mogę utworzyć out"));
    for f in &findings {
        serde_json::to_writer(&mut w, f).expect("json");
        w.write_all(b"\n").expect("zapis");
    }
    w.flush().unwrap();

    // podsumowanie: kind x verdict
    let mut counts: BTreeMap<(&'static str, &'static str), usize> = BTreeMap::new();
    for f in &findings {
        let v = match f.verdict {
            Verdict::Candidate => "CANDIDATE",
            Verdict::Excluded => "excluded-§8",
            Verdict::Info => "info",
        };
        *counts.entry((f.kind, v)).or_default() += 1;
    }

    eprintln!("plików-analizą objęte wejście: {:?}", paths);
    eprintln!("obserwacji: {} ({} ms, wątki: {})", findings.len(), elapsed.as_millis(), rayon::current_num_threads());
    for ((k, v), n) in &counts {
        eprintln!("  {k:<14} {v:<12} {n}");
    }
    eprintln!("wyniki → {out}");

    if summary {
        println!("\n=== TOP kandydaci (Candidate) ===");
        for f in findings.iter().filter(|f| f.verdict == Verdict::Candidate) {
            println!("[{}] {}  <-  {}", f.kind, f.value, f.file);
        }
    }
}
