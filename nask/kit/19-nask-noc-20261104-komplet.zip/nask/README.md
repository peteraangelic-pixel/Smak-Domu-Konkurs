# NASK bug bounty — hack.cert.pl edycja 11/2026 (folder roboczy tej sesji)

Start programu NASK: 3–30.11.2026. Pula 5 programów ~1 mln zł (NASK 100k).
Płacą **tylko pierwsze zgłoszenia**; zgłoszenie = formularz hack.cert.pl (po zalogowaniu)
+ PoC + instrukcja odtworzenia. Regulamin: max 5 req/s automatyki, konta własne/testowe,
raporty ze skanerów bez ręcznego potwierdzenia WYKLUCZONE (§8). Władysławowo pomijamy.

## Zawartość

| Plik/katalog | Co to jest |
|---|---|
| `PLAN-NOCNY-2026-11-03.md` | co zrobione tej nocy + plan kolejnych noćnych tur + guardy |
| `IDEE-ZAROBEK-2026-11-03.md` | rank pieniędzy (mSzyfr → hack.cert.pl → panele CERT), kalibracja 1–2 × 4–9k zł/mies, czego nie robić |
| `recon/MAPA-ENDPOINTOW-2026-11-03.md` | wynik rekonesansu: `/api/sendForm`, embed PowerBI na oad, hipotezy z warunkami odrzucenia |
| `recon/LOG-POBRAN-20261103.md` | pełny log 49 GET-ów (1 req/s, publiczne strony+JS) |
| `recon/evidence-20261103/` | surowy materiał: 3 HTML + 46 bundli JS (3.9 MB) |
| `recon/MINER-WYNIKI-20261103.jsonl` | 590 obserwacji endminera (kind/verdict/reason) |
| `rust/endminer/` | **endminer** — narzędzie offline Rust+Rayon: endpointy/ID/param/sekrety z bundli, klasyfikator §8; 8/8 testów PASS |
| `bin/endminer` | binarka release z sandboxa (x86_64 linux) |
| `.github/workflows/endminer-ci.yml` | CI: build+test (bez żadnego ruchu do hostów) |

## Jak używać endminera (lokalnie, na Ryzena)

```bash
# 1) Zapisz material jako pliki (np. przeglądarka „Zapisz jako" albo curl), potem:
chmod +x bin/endminer ./bin/endminer katalog./bin/endminer katalog ./bin/endminer katalog-z-plikami --out wynik.jsonl --summary
# verdict CANDIDATE = hipoteza do ręcznej weryfikacji na własnym koncie
# verdict excluded-§8 = NIE zgłaszać (regulamin)
# 2) Dev (testy):
cd rust/endminer && cargo test --release
```

## Kontekst między-sesyjny (co już istnieje poza tym folderem)

- Repo `peteraangelic-pixel/NASK` (gałęzie `arena/a29ca234-nask`, `codex/multi-program-lab-20261103`):
  `coordinator/` (programs.json 26 hostów, scope guard, limiter 4,5 req/s),
  `python/jsminer.py`, workflow `scan.yml`, Drive-materiały (10 = szablon raportu, 12 = gen_report.py).
- Pokemon `arena/a450b00f-pokemon` → `nask/`: MAPA-PUBLICZNA, START-HERE, POSTEP-I-AUDYT
  (collector wymaga poprawek), archiwum.
- Google Drive folder `1tWcRm79…` (15 plików 00–14; 13-STRATEGIA = 5 programów).
- Wynik istotny z innych sesji: **anonimowy skan = 0 płatnych zgłoszeń** — pieniądze
  są w logice aplikacji wymagającej sesji (IDOR/ATO/upload/mass assignment).

## Push

Brak poświadczeń w sandboxie → repo jest push-ready (gałąź `arena/night-nask-20261103`):

```bash
cd nask
git remote add origin git@github.com:peteraangelic-pixel/NASK.git
git push -u origin arena/night-nask-20261103
```

## Pułapka środowiska (dla kolejnych sesji)

Snapshot workspace: (1) zdejmuje bit wykonywalny — po odtworzeniu `chmod +x bin/endminer`;
(2) nie utrwala `.git/config` — repo pada między turami; po powrocie zrobić `git init`
+ jeden commit zbiorczy (pliki zawsze są całe), push dopiero z maszyny usera.
