<!DOCTYPE html><html lang="en" style="height: 100%;"><head>
    <meta charset="utf-8"/>
    <title>mSzyfr</title>
    <link rel="apple-touch-icon" sizes="120x120" href="custom_welcome/120.png"/>
    <link rel="apple-touch-icon" sizes="144x144" href="custom_welcome/144.png"/>
    <link rel="apple-touch-icon" sizes="152x152" href="custom_welcome/152.png"/>
    <link rel="apple-touch-icon" sizes="180x180" href="custom_welcome/180.png"/>
    <link rel="manifest" href="manifest.json"/>
    <meta name="referrer" content="no-referrer"/>
    <link rel="icon" type="image/png" sizes="24x24" href="custom_welcome/24.png"/>
    <link rel="icon" type="image/png" sizes="144x144" href="custom_welcome/144.png"/>
    <link rel="icon" type="image/png" sizes="512x512" href="custom_welcome/512.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="apple-mobile-web-app-title" content="mSzyfr"/>
    <meta name="application-name" content="mSzyfr"/>
    <meta name="theme-color" content="#ffffff"/>
    <meta property="og:image" content="https://app.element.io/themes/element/img/logos/opengraph.png"/>
    <meta http-equiv="Content-Security-Policy" content="
        default-src &#39;none&#39;;
        style-src &#39;self&#39; &#39;unsafe-inline&#39; ;
        script-src &#39;self&#39; &#39;wasm-unsafe-eval&#39; https://www.recaptcha.net/recaptcha/ https://www.gstatic.com/recaptcha/ ;
        img-src * blob: data:;
        connect-src * blob:;
        font-src &#39;self&#39; data: ;
        media-src * blob: data:;
        child-src * blob: data:;
        worker-src &#39;self&#39; blob: ;
        frame-src * blob: data:;
        form-action &#39;self&#39; ;
        manifest-src &#39;self&#39; ;
    "/>
    
           <link rel="stylesheet" href="bundles/622bdb601d5a4764b1d4/bundle.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Legacy-light" title="Legacy-light" href="bundles/622bdb601d5a4764b1d4/theme-legacy-light.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Legacy-dark" title="Legacy-dark" href="bundles/622bdb601d5a4764b1d4/theme-legacy-dark.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Light" title="Light" href="bundles/622bdb601d5a4764b1d4/theme-light.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Light-high-contrast" title="Light-high-contrast" href="bundles/622bdb601d5a4764b1d4/theme-light-high-contrast.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Dark" title="Dark" href="bundles/622bdb601d5a4764b1d4/theme-dark.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Light-custom" title="Light-custom" href="bundles/622bdb601d5a4764b1d4/theme-light-custom.css"/>
        
           <link rel="stylesheet" disabled="disabled" data-mx-theme="Dark-custom" title="Dark-custom" href="bundles/622bdb601d5a4764b1d4/theme-dark-custom.css"/>
        

    

  <link rel="stylesheet" href="custom_welcome/custom.css"/></head>
  <body style="height: 100%; margin: 0;">
    <noscript>Sorry, Element requires JavaScript to be enabled.</noscript> <!-- TODO: Translate this? -->
    <div id="matrixchat" style="height: 100%;" class="notranslate"></div>

    <script src="bundles/622bdb601d5a4764b1d4/bundle.js"></script>


    <!-- Legacy supporting Prefetch images -->
    <img src="" aria-hidden="" alt="" width="24" height="23" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>
    <img src="" aria-hidden="" alt="" width="25" height="22" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>
    <img src="" aria-hidden="" alt="" width="25" height="22" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>
    <img src="" aria-hidden="" alt="" width="25" height="22" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>
    <img src="" aria-hidden="" alt="" width="25" height="22" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>
    <img src="" aria-hidden="" alt="" width="25" height="22" style="visibility: hidden; position: absolute; top: 0px; left: 0px;"/>

    <!-- let CSS themes pass constants to the app -->
    <div id="mx_theme_accentColor"></div><div id="mx_theme_secondaryAccentColor"></div><div id="mx_theme_tertiaryAccentColor"></div>

    <!-- We eagerly create these containers to ensure their CSS stacking context order is sensible -->
    <div id="mx_PersistedElement_container"></div>
    <div id="mx_Dialog_StaticContainer"></div>
    <div id="mx_Dialog_Container"></div>
    <div id="mx_ContextualMenu_Container"></div>
  <script src="custom_welcome/custom.js"></script>

</body></html>