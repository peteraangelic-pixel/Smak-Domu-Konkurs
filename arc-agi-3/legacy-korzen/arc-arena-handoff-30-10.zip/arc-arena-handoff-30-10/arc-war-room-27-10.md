# 🧩 ARC-AGI-3 — WAR ROOM, UPDATE 2026-10-30 (do 2.11: 3 dni)

> **UPDATE 30.10 (po slocie A):**
> - Slot A (v11/v12) wysłany — wynik **~23** (poniżej duck v3 = 26.25).
>   ANALIZA-23.md wyjaśnia to bez awarii: (1) rozcieńczenie tokenów na pełnym rosterze
>   (smoke 10 gier ≠ 9 h pełnego rosteru), (2) **poszła kontrola, nie wariant plan**
>   (PLAN_COMMIT=0 — wariant planu NIGDY nie zagrał w punktanym biegu!), (3) cap 45k
>   kosztuje (su15: 56.4→13.3), (4) w punktowanym biegu n_passes=1 — pamięć działa
>   inaczej, niż zakładano (naprawione w v13.1), (5) wariancja ±2–3 pkt to norma.
> - **Nowy główny kandydat: duck-v13.1** (baza v11 bajt-w-bajt + PLAN_COMMIT=1 +
>   cap OFF + pamięć zwycięskich ścieżek z deterministycznym replayem + playbook
>   14 poziomów / 9 gier zwalidowany na prawdziwym silniku + dead-skip na licznikach
>   magazynu; 3 niezależne recenzje potwierdziły: patche 6/6, testy 12/12 + 6/6,
>   playbook 14/14). Kill-switche po jednej wartości. Oczekiwania uczciwie: **28–38**.
> - **Plan na 3 dni:** dziś push + Submit v13.1 (owner!) → równolegle `pc-sweep-pack`
>   (dokładanie poziomów BFS-em na PC — najtańsza dźwignia wg README) → 1.11 ostatni
>   slot: v13.2 z większym playbookiem (jeśli sweep dał poziomy) albo re-run v13.1.
>   Notebook publiczny od razu po COMPLETE. Z logów biegu ~23 wyciągnąć 3 linie
>   (wariant / cap / rozmiar rosteru) — kalibracja v13.1 + materiał na paper track.

---

# (stan z 27.10 — archiwum kontekstu)

Cel dokumentu: jedna strona prawdy dla wszystkich gałęzi wspomagających ARC
(7911f950, a450b00f, c87f7a48 w Pokemon; c4eeb067, 6d081d52 w Gemma; 5ed750ef w Smak)
+ decyzja do podjęcia TERAZ przez ownera.

---

## 1. SYTUACJA LICZBOWA (zweryfikowana, stan 25.10 wieczór)

| Fakt | Wartość | Źródło |
|---|---|---|
| Nasz najlepszy oficjalny COMPLETE | **duck v3 = 26.25** | a450 DECYZJA §1 |
| Smoke c45 (zdrowy przebieg) | 26.78, 32 poziomy | a450 §1 |
| c45 oficjalny rerun | **0.00** (#57629847) | a450 §1 |
| Przyczyna 0.00 (weryfikowalna w kodzie) | `concurrency=120` vs serwer **MAXREQ=10** → głód slotów | Smak DIAGNOZA + a450 §1 |
| Sufit ruchów (z ekonomii r019) | ~29.0 | a450 §4 |
| +1 poziom/grę | ≈ 44.0 | a450 §4 |
| **Próg nagród (LB 24.10)** | **49.85** (wzrost z 40.97 — pole ucieka) | c87 live 24.10 |
| Kwota GPU | ~30 h/tyg → **realnie ~2 sloty do końca** | a450 §5 |
| **Wymóg publicznego notebooka finalisty** | **31.10–1.11**, inaczej nagroda przepada | a450 §5 |
| Osobna ocena (7911f950, 24.10) | publiczny sufit 34.3; „45+ nieosiągalne" | MY-WORK/honest status |

**Wniosek liczbowy (skorygowany po pytaniu ownera):** 49.85 wymaga ~**+2 poziomy/grę**
ponad obecny stan, a zmierzony postęp całej koalicji przez 3 tyg. to ~+1 punkt łącznie.
To **nie jest dowód matematyczny** — to szacunek z własnych sufitów (nieznany prywatny
roster i wzór scoringu wprowadzają niepewność). Poprawne sformułowanie: *nagroda wymaga
skoku ~20× większego niż dotychczasowy postęp, w 6 dni, przy ~2 slotach — prawie na pewno
nieosiągalna, ale nie zero*.

**Dlatego NIE rezygnujemy z walki — zmieniamy cel funkcji:**
1. Slot A bankuje pewny wynik (~26–27) = miejsce ~6–15 na LB (mocny rezultat + najlepsza
   reklama dla paper tracku, który jest OSOBNĄ pulą $ i ocenia opis, nie wynik).
2. Slot B to zakład o upside (PLAN_COMMIT=1 / ratowanie poziomów) — tani, bo slot i tak wolny.
3. Szanse na top-5 żyją w scenariuszach: prywatny roster sprzyja naszym mechanizmom,
   pole zamarza przed 2.11, albo repo-holdout pokaże powtarzalny skok (+2 poziomy).
   Wszystkie niskoprawdopodobne — ale slot B istnieje dokładnie po to, żeby je testować.

## 2. WKŁAD GAŁĘZI (kto co wniósł — wzajemnie zweryfikowane)

| Gałąź | Wkład do ARC |
|---|---|
| **Smak 5ed750ef** | infrastruktura ops (r076–r085: push kerneli, pick outputów, kontrola statusów); **DIAGNOZA 0.00** (concurrency 120/10); certyfikacja offline v11-Codex (CRLF, chunki<400k, git apply PASS r033); sprzątanie repo (2.5 GB!) |
| **a450b00f** | **DECYZJA.md = dokument konsolidacyjny**; wariant B zrealizowany: **duck-v11** (port na sprawdzonym c45 + commit(plan) z bramkami + fix concurrency; ALL CHECKS PASSED); falsyfikacja v10 (patch nie aplikuje się na bundle, PROFILE=plan domyślny); zamknięcie sporu o „martwy patch" (IPython dopisuje `\n` — patch działał zawsze); przeliczona ekonomia r019; recenzje pakietów DeepSeek-v9, e499-v10, Smak-v11 i wkładów Gemma |
| **c87f7a48** | live dane LB 24.10 (próg 49.85, deadline 2.11); EKONOMIA-TOKENOW (model wyniku ~ tok/akcje); POROWNANIE-V11; korekty własnych błędów (concurrency=120, level-cap); triage budżetowy po recenzji DeepSeek 4.1 |
| **7911f950** | honest status 24.10 (sufit 34.3); CPU harness na prawdziwym silniku; Rust→solver przez JSONL; infrastruktura RL/BC (inspiracje z… Pokemona 😄); DUCK-V8-VERIFIED (korekta własnego błędu o „nieistniejącym" v8); koordynacja COORDINATION-17OCT |
| **Gemma c4eeb067** | dwie analitki koncepcyjne: **„ARC punktuje to, co domkniesz, nie jak dobrze"** (wzór punktacji premiujący poziomy) i **„brakująca zmienna: ile kosztuje decyzja"**; repo-holdout z pre-rejestracją (łatanie dziury, która zmywałaby screeningi); równolegle własne V7-c/V8 + start LoRA SFT |
| **Gemma 6d081d52** | ARC cross-branch findings + review (dokumentowane w notes/) |

To jest już funkcjonalnie **zespół przeglądowy (peer review) 6 sesji** — i to działa:
każdy większy claim kogoś innego został potwierdzony lub sfalsyfikowany twardymi
artefaktami (przykłady: v10 obalone przez a450; „martwy patch" obalony przez a450+c87;
v8 „nie istnieje" obalone przez 7911f950 samemu sobie).

## 3. DECYZJA, KTÓRĄ TRZEBA PODJĄĆ DZISIAJ (GO ownera)

Plan slotowy z DECYZJA.md jest dobry; dokładam do niego analizę decyzyjną:

**Slot A (teraz → najpóźniej 29.10): `duck-v11` z `PLAN_COMMIT="0"`**
- To jest c45 + fix concurrency, bez nowego ryzyka. Jeśli diagnoza 120/10 jest prawa,
  oczekiwany wynik ≈ smoke (26.7), czyli **nowy oficjalny rekord i bezpieczny finalist**.
- To zgłoszenie jest **kandydatem na finał**: mechanizmy roster-agnostyczne ( concurrency
  fix i commit(plan) nie zależą od playbooka 25 publicznych gier — a ryzyko „prywatny
  roster ≠ publiczny" jest realne i wszyscy je odnotowaliście).
- **Zrób go publicznego OD RAZU po COMPLETE** (nie 31.10 — kolejki, strefa czasowa,
  awarie). Publiczność nie kosztuje nic, jej brak kosztuje wszystko.

**Slot B (po wyniku A, do ~31.10): warunkowo**
- A ≥ 26 → slot B = `PLAN_COMMIT="1"` (upside: ratuje poziomy; kill-ryteria już
  spisane w DECYZJA §5).
- A < ~15 (diagnoza 0.00 nietrafiona) → slot B = **czysta kontrola v3** (jedyne
  potwierdzone COMPLETE) — zabezpieczamy finalist zamiast hendikepować.
- Nie testować `deep`/`wide` — zabawa profilami to strata jedynego slotu upside.

**Czego NIE robić do 2.11:** nowych mechanizmów, refaktorów, kolejnych recenzji
pakietów v12+. Wszystko, co przyszło po duck-v11, idzie do backlogu na przyszły rok.

## 4. RYZYKA (register)

1. **Rerun ≠ smoke** — c45 już raz zjadł 0.00 mimo zdrowego smoke'a. Mitigacja:
   slot A celowo minimalizuje dyference (same pokrętła concurrency), a nie nowy kod.
2. **Prywatny roster gier** — playbook/triage mogą być warte zero; dlatego finalist
   ma być roster-agnostyczny (patrz wyżej).
3. **Eligibility/KYC** — poprzedni projekt (riemann) zgasł na wymogach. Kaggle-owa
   nagroda $75k ma być „wynikiem bez writeupu", ale **KYC przy wypłacie to otwarte
   pytanie**. Wysłać zapytanie do ARC Prize Foundation DZIŚ (mail/support ticket) —
   odpowiedź i tak zajmie dni, a dotyczy decyzji „ile nas to obchodzi po 2.11".
4. **Ops singleton** — operatorska gałąź 98ddb59f stoi od 15.10; okazało się, że
   sekrety ma też Smak (wykonała r076–r085), więc ryzyko jest zdywersyfikowane.
   Mimo to: **klik „Submit to Competition" w UI zawsze należy do ownera** (post-mortem
   z 10.10: CLI nie uruchamia biegu konkursowego).
5. **Kwota GPU** — ~2 sloty. Żadnego „odpalamy, żeby zobaczyć" — każdy slot wg §3.

## 5. STATUSY POBOCZNE (kontekst, nie ARC)

- **Gemma oficjalnie: 0.03 → 0.13 (V5, 14.10) → 0.08 (16.10)** — hipoteza V5
  POTWIERDZONA (>4×). Korekta 0.08 (najpewniej V6.2 z twardymi deadline'ami) sugeruje,
  że agresywny pacing oficjalnie SZKODZI. Na paper track (12.11): macie świetny łuk
  narracyjny 0.03→0.13→0.08 + falsyfikacje O1/O2 + „screening ≠ ukryty zbiór".
  **Zacząć pisanie teraz — zostało 16 dni.** I: opisywać zgłoszenia w polu description
  (V5/V6.2…), żeby wyniki były czytelne w historii.
- **Pokemon:** ostatni znany rekord 468.3 (15.10) vs mediana ~650; rekomendacja
  z 15.10 (RL zamiast mikro-optymalizacji) pozostaje aktualna — ale ARC ma pierwszeństwo
  do 2.11.

## 6. CHECKLISTA OWNERA (kolejność)

- [ ] Dziś: GO dla **slotu A** (duck-v11, PLAN_COMMIT=0) → push przez CI Smaka/a450
  + **klik „Submit to Competition" w UI** (tylko owner).
- [ ] Po COMPLETE: notebook **publiczny** natychmiast; wynik do ledgera.
- [ ] Dziś: mail do ARC Prize Foundation (KYC/eligibility przy wypłacie).
- [ ] 29–31.10: decyzja o slocie B wg reguły z §3.
- [ ] 31.10–1.11: finalista publiczny (zabezpieczone już w kroku 2).
- [ ] Równolegle (30 min): outline paper tracku Gemma (deadline 12.11).

---

# UPDATE 30.10 (~10:30 UTC) — TRZY NIEZALEŻNE SCALENIA + v16-NAJ (ARENA)

W ciągu 13 minut trzy gałęzie wydały swoje "best-of": **Pokemon duck-v15** (8d96c68f,
08:10: v14 + własna implementacja eskalacji względnej 0007, 7/7 r033; **kluczowe: baseline'y
UKRYTE w submisji → eskalacja względna degraduje do absolutnych 20 + cap 2/level**),
**Gemma duck-v15** (07bf05e0, 08:12: v13.3-arena + ESCALATE=20 + sondy, bez nowych patchy;
korekta: HISTORY_ASSISTANT_TURNS default = 30, nie 150; mechanizm: akcje/grę =
czas/(tok/akcję×17,2 ms), ~85% czasu akcji = generowane tokeny), **Smak v13.4-unified**
(f04c3e73, 08:15: v13.2+v13.3+v14+patch 0008 eskalacji względnej; **8/8 patchy czysty r033,
12+6+11 testów, sondy, guard hooka; prognoza 26–31; propozycja slotów 30.10/31.10/1.11/2.11;
CZEKA NA GO**).

**v16-naj (Arena, `arc-v16-package/`)** = baza v13.4-unified (najlepiej skodyfikowana
certyfikacja) + **patch 0009 adaptacyjny budżet poziomu** — jedyny element, którego nie ma
żadne ze scaleń. DORMANT (cap=0 → zachowanie ≡ v13.4; podwójny bezpiecznik), uzbrojenie
jedną wartością (`ARC3_LEVEL_TOKEN_CAP 0→60000`) jako kandydat na flip 1.11. Lokalnie:
**ALL LOCAL CHECKS PASSED** (24 checki + 16 testów; cell-diff vs baza = kom. 1, 2 + writer
extra-07; 0009 bez kolizji plikowej z 0008). ⚠️ Slug `petersharps/arc3-duck-v15` ZAJĘTY
przez Pokemon-metadata — nie pushować starych "v15" bez sprawdzenia. Bramka trio: 9 patchy
na czystym r033 + smoke + GO.


## UPDATE 30.10 (~11:50 UTC) — nowa sesja: duck-v17-action-efficiency + leaderboard

- Owner wgrał na Smaka (283a36b8, root gałęzi): `action_efficiency_layer.py`, `agent.py`,
  zip (warstwa PlanCache/ConvergedGuard/BudgetLedger + 4 mikro-środowiska + audyt + AVX512).
  Pełna recenzja: **arc-review-duck-v17-action-efficiency.md**.
- Zweryfikowane samodzielnie: testy **7/7**, eval **odtwarza się dokładnie** (RHAE 3.80→40.06).
- **Luka atrybucji**: 40.06 mierzy PlannerAgent vs ReactiveAgent (BFS+tabela efektów+inferencja
  celu), a NIE warstwę — warstwa nie jest używana w eval'u. "12 seedów" = de facto 1
  (fabryka ignoruje seed; stdev 0.00).
- Cenne: ConvergedGuard (hash stanu, pętle dłuższe niż okno), zasada "Δ mediany akcji/
  ukończony poziom" + bramka Δ≤0, pułapka "obiekt pod graczem zasłonięty", uczciwość STATUS.
- Ryzyka integracji: PlanCache koliduje z filozofią 0006 (tylko frame-verified — cache wszystkiego
  pali AKCJE), BudgetLedger koliduje z priority schedulerem (dwa harmonogramy). Warstwa =
  kandydat na flip 1.11 po Δ na r085, NIE slot 30.10.
- Intel leaderboardowy (ich audyt, przyjąć jako hipotezę): **TOP-1 Yi-Chia Chen 75.56,
  TOP-2 Tufa Labs 70.02, TOP-3 faster machine 58.59**; nasze: 23.89 / 1.18.
- Rekomendacja slotów bez zmian: 30.10 v13.5-consensus (lub v17-naj po weryfikacji trio),
  31.10 drugi bieg/kontrola, 1.11 flip (0010 uzbrojenie / self-pace / warstwa po Δ),
  2.11 select best. **Deadline 2.11 = 3 dni.**
