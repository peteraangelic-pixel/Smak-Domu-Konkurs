# 📊 PORÓWNANIE: v16-naj (Arena) vs najnowsze wersje wszystkich gałęzi
**Stan: 30.10.2026 ~11:15–11:45 UTC. Trzy dni do finału ARC (2.11). Wszystko poniżej = offline (bez smoke'a GPU).**

## 0. Timeline poranka (co nowego powstało po moim v16 ~08:20)

| godz (UTC) | gałąź | wydanie | typ |
|---|---|---|---|
| 08:22 | Pokemon 7911f950 | **v17** (V17-COMPARE.md + v17_policy.py) | analiza, brak kernela |
| 08:27 | Smak 5ed750ef | **v13.5-consensus** (63ede621) | KERNEL, 39 komórek |
| 08:30 | Pokemon c87f7a48 | 10. korekta (3,6× = artefakt) | docs |
| 08:38 | Gemma c4eeb067 | **duck-v16** (0ef24651) | KERNEL, 41 komórek |
| 08:43 | Pokemon a450b00f | audyt v13.4 ("1 rysa") | docs |
| 08:44 | Gemma | STATUS.md (punkt wejścia) | docs |

## 1. Główna tabela porównawcza (kernele)

| | **Arena v16-naj** (8:20) | **Smak v13.5-consensus** (8:27) | **Gemma duck-v16** (8:38) |
|---|---|---|---|
| baza | v13.4-unified | v13.4-unified (builder przyrostowy) | v13.4-unified (łańcuch zweryfikowany na czystym r033 **przez Gemmę**) |
| nowe patche | **0009 dyn-budget** (dormant; `arc3_level_budget.py`) | **żadnego** (tylko kom. 2 + sondy) | **0009 self-pace** (`tool_agent.py`) |
| eskalacja w rerunie | absolutna 20 + cap 2 (0008 degeneruje — baseline ukryty) | j.w., **degradacja udokumentowana w kom. 2 i MIERZONA sondą baseline** | absolutna 20 + cap 2 **+ self-pace: próg z WŁASNEGO rekordu gry (`GameRun.actions_per_level`, nigdy nieukrywany): clamp(1,5×mediana, 20, 120), max 2/level** |
| r085 nudge'y (przedwczesne) | 42 (26/32) [@20+cap2] | 42 (26/32) | **22 (14/32) self-pace** · 42 (26/32) [@20+cap2] · korekta: @20=67 surowe |
| sondy | budżet + roster (z v13.4) | budżet + roster **+ widoczność baseline + pokrycie ważone (sufit wyniku wprost)** | budżet + roster + **sonda pokrycia** (coverage, baseline yes/no, a/call, tok/akcję → coverage_probe.json) |
| nowy intel wkomponowany | — | tak (7911: 4,61 akcji/gen, 186k tok/grę; reguła `score ≤ 100×pokrycie` 30/30; Gemma-audit) | tak (@20=67 nie 60; sweep playbooka 0/3 — uczciwie nieobiecane) |
| weryfikacja | lokalna: 24 checki + 16 testów (0009 na rekonstrukcji 0004) | **8/8 r033 + 12+6+11 testów + sondy na stubach** (certyfikat autora; a450 niezależnie: 8/8, 12/12, 11/11, 5/6) | 7/7 pakiet (fixtures: diff(pre,post)==patch!) + 11/11 winpath + sondy; **łańcuch 8 patchy zweryfikowany na czystym r033 przez nią** |
| slug Kaggle | `arc3-duck-v16` (**unikalny**) | `arc3-duck-v13-5-consensus` (unikalny) | ⚠️ **`arc3-duck-v13-4-unified`** = slug Smaka! Push Gemmy nadpisze kernel v13.4 jako wersję 2 |
| progi GO | — | a/call ≥ 1,8 | a/call ≥ 1,8 (Gemma) — **7911: niemożliwy do obalenia** (najgorszy run 4,57 = 2,5× progu) |

## 2. Analiza 7911-v17 (nie jest kernelem, ale zmienia obraz)

- ⚠️ **Teza „v13.4 NIE ISTNIEJE" = FAŁSZYWA** (stary klon; sprawdzone 08:22, v13.4 opublikowane
  08:15:58). Ja mam notebook v13.4 i zweryfikowałem go lokalnie; a450 i Gemma niezależnie
  potwierdziły łańcuch. Reszta analizy 7911 pozostaje wartościowa:
- **Prawdziwa dźwignia = hint na openerze, stosunek 24:1 do całego sporu o eskalację.**
  Arytmetyka: 186 200 tok/grę; 4,61 akcji/generację → 853 tok/akcję → 218 akcji/grę (za mało);
  **połowa** efektu hinta (a/call 5,62) → 700 tok/akcję → 266 akcji/grę ≥ 253 → **50 pkt**.
  Cały spór 10 vs 20 vs względny = różnica **2 akcji/grę** (0,95%→0,03% budżetu).
- **Bramka**: Gemma `a/call ≥ 1,8` nie może paść (najgorszy zmierzony run 4,57). Sensowna
  bramka 7911: **`a/call ≥ 6,0`** — leży dokładnie na granicy 253 akcji/grę.
- Dwa rozbieżne „duck-v15" (a450 vs Gemma) = kolizja NAZW, nie kodu; pliki rozłączne.

## 3. Nowe intel zwalidowane krzyżowo

1. **Baseline ukryty w submisji** (`base_actions_per_level is None`, a450 sprawdził na r033,
   potwierdzone w `taaf/game.py`) → **0008 (względny) jest martwy w rerunie we wszystkich
   pakietach, które go mają** (Smak v13.4/13.5, a450 v15). Degraduje do absolutnych 20+cap2.
   Smak: 42 wstrzyknięcia (2,9% puli) — bezpiecznie; dokumentuje + mierzy sondą.
2. **Gemma 0009-self-pace = JEDYNA eskalacja, która działa w rerunie**: kalibruje na
   `GameRun.actions_per_level` (nasz własny rekord — nigdy nieukrywany). 22 nudge'y/14
   przedwczesnych vs 42/26 przy 20+cap2. Env-gated (`ARC3_ESCALATE_SELF_PACE=0` → exact v13.4).
3. **Reguła sufita**: `score = min(raw, cap) ≤ 100 × pokrycie` (30/30). Pokrycie ~29% → ~29 pkt.
   Do 50 brakuje **+1,1 poziomu/grę = +22% budżetu akcji** (206→253).
4. **Model budżetu (7911, przyjęty przez Smaka)**: model ogranicza DEKODOWANIE
   (~186k tok/grę, 4,61 akcji/generację, 853 tok/akcję). Dźwignia = mniej tok/akcję —
   hint to dokładnie realizuje (mniej tur → mniej tokenów na akcję).
5. **Spór o historię rozstrzygnięty**: Gemma miała rację o domyślnej (30), ale **notebook pinuje
   `ARC3_HISTORY_ASSISTANT_TURNS: 150` w setup_env (kom. 15)** → opcja „150→48" Smaka jest
   poprawna dla ich pakietu; sam trim pozostaje niezmierzony (nie wchodzi nigdzie).
6. **„1 rysa" v13.4 (a450)**: test R085 bez skip-guarda pada z czystego klona
   (`IsADirectoryError` bez `R085_BENCH`) — błąd TESTU, nie pakietu. Moje testy tego nie mają.
7. **c87 „3,6× luka silnika" OSTATECZNIE obalona** (r110 = 27B/vLLM; porównanie dwóch modeli).

## 4. Werdykt: gdzie stoi mój v16-naj

**Jako kandydat na slot — przestał być nr 1.** Dziś slot powinien zagrać czymś, co daje
aktywną wartość ponad v13.4:
- **v13.5 > mój v16 na dziś**: mój v16 ≡ v13.4 w zachowaniu (0009 dormant) → wnosi ZERO
  aktywnego zachowania, tylko uzbrojenie na później. v13.5 wnosi aktywne obserwowalne
  (sufit pokrycia + widoczność baseline) i skonsensusowane dokumenty — **ten sam bieg,
  więcej diagnozy**.
- **Gemma v16 ma jedyny żywy nowy mechanizm** (self-pace działa w rerunie) — ale zmienia
  zachowanie bez smoke'a i **jej metadata celuje w slug v13.4 Smaka** (ryzyko nadpisania).
- **Mój unikat przetrwał**: dyn-budget (0010-kandydat) to nadal **jedyny mechanizm głębi**
  (odzysk tokenów z poziomów-odpadów) i jedyna dźwignia uzbrajalna jedną wartością w 1.11 —
  nikt inny tego nie ma, pliki rozłączne z wszystkim.

## 5. Prawdziwy best-of-now („v17-naj") — rekomendacja

**Baza: v13.5-consensus + patch Gemmy 0009-self-pace + mój dyn-budget przenumerowany na 0010
(extra-08) + bramka 7911 (a/call ≥ 6,0).** Wszystkie trzy komponenty dotykają rozłącznych
plików (v13.5: brak patchy; self-pace: tool_agent.py; mój: arc3_level_budget.py) → kompozycja
czysta. Self-pace jako domyślnie WŁĄCZONY (env-gated, mierzony) albo bezpieczniej: włączony,
bo v13.5 i tak mierzy widoczność baseline sondą.

Propozycja slotów (spójna z The Smak, decyduje GO):
| slot | co | uzasadnienie |
|---|---|---|
| 30.10 | **v13.5-consensus** (albo v17-naj, jeśli zdążymy zweryfikować) | pełny nadzbiór + diagnoza |
| 31.10 | v17-naj (self-pace + dormant 0010) LUB powtórka v13.5 | jedyny żywy nowy mechanizm |
| 1.11 | flip wg sond: uzbrojenie 0010 (`LEVEL_TOKEN_CAP 0→60000`), `SELF_PACE=0`, `HISTORY 150→48` | tylko uzbrajalne dźwignie |
| 2.11 | select best | — |

**Higiena slugów (ważne!)**: Gemma ma obecnie 2 kernele wskazujące na cudze slugi (v15→
`arc3-duck-v13-3-arena`, v16→`arc3-duck-v13-4-unified`) — przed jakimkolwiek pushem z ich
gałęzi poprawić metadata, inaczej nadpisze kernele Smaka. Moje `arc3-duck-v16` i moje
`arc3-duck-v15` (starszy pakiet) są unikalne.
