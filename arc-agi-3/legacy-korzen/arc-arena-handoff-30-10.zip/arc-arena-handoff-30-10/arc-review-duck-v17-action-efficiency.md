# 🔍 REVIEW: duck-v17-action-efficiency (nowa sesja Arena.ai, upload 283a36b8, 09:14 UTC)

**Co sprawdzono:** 3 pliki wgrane do roota gałęzi Smaka: `action_efficiency_layer.py` (199 l.),
`agent.py` (301 l.), `arc3_duck-v17-action-efficiency.zip` (16 plików: warstwa, sym, 2 agenty,
testy, eval, results.json, RAPORT.html, STATUS.md, audyt, AVX512, PUSH_INSTRUCTIONS, README).
**Recenzja niezależna — wszystko poniżej odpalone samodzielnie w sandboxie.**

## 1. Weryfikacja deklaracji (odtworzone, nie cytowane)

| deklaracja | moja reprodukcja | werdykt |
|---|---|---|
| `test_layer.py` → 7/7 | **7/7 PASS** (18 s) | ✅ |
| `run_eval.py` → RHAE 3.80 → 40.06 | **3.80 → 40.06, +36.26 — identycznie** (już przy 8 seedach) | ✅ odtwarzalne |
| metryka labu wg docs.arcprize.org | wagi k=1..n, `min((h/ai)², 1.15)`, nieukończony=0 — **zgodna ze zweryfikowanym wzorem 32/32** (PLAN-50) | ✅ |
| „12 seedów" | ⚠️ **kosmetyka**: fabryka agenta ignoruje seed pętli (`lambda: ReactiveAgent(seed=0)`), stdev = 0.00 wszędzie, wyniki identyczne przy 8 i 12 seedach → de facto **1 deterministyczny przebieg** | ⚠️ |
| „warstwa przegrywa 2/4 gier" | potwierdzone: switchorder 0.00 (remis obu), colorclicks **0.00 vs 5.89** (realna przegrana) | ✅ uczciwe |
| TOP-1 = 75.56 (Yi-Chia Chen), Tufa 70.02 | **nowy intel leaderboardowy**; nie weryfikowałem źródła samodzielnie (ich audyt: Kaggle + docs.arcprize.org) | ℹ️ przyjąć jako hipotezę |
| „zostały 4 dni" | ❌ deadline **2.11** → zostały **3 dni** | drobna korekta |

## 2. KLUCZOWY FINDING: luka atrybucji w deklaracji 40.06

`run_eval.py` porównuje **dwa pełne agenty**: `ReactiveAgent` (greedy + szum noop/forget) vs
`PlannerAgent` (**BFS + tabela efektów + odrzucanie martwych celów + inferencja celu +
portfolio porządkowań**). **Warstwa (`PlanCache`/`ConvergedGuard`/`BudgetLedger`/`HarnessHook`)
nie jest używana w eval'u nigdzie** — `agent.py` jej nie importuje, `run_eval.py` też.

Czyli: „RHAE 3.80 → 40.06" **mierzy wartość planowania, nie wartość warstwy**. Docstring
warstwy („Zmierzone w arc3_lab: RHAE 3.80 → 40.06") przypisuje wynik, którego warstwa
nie wygenerowała. STATUS.md i chat są bliżej prawdy („moja wersja to planner vs reaktywny"),
ale każdy, kto przeczyta tylko nagłówek, dostanie fałszywy obraz przyrostu.

**Co to znaczy praktycznie:** przyrost z warstwy NA WIERZCHU istniejącego harnessu jest
**niezmierzony**. W labie warstwa nie ma jak pokazać wartości (żadnych re-setów epizodów →
PlanCache bezrobotny; poziomy liczone niezależnie → Ledger bezrobotny; jedyny testowalny =
ConvergedGuard). Jedyna uczciwa miara pozostaje ich własna propozycja: **Δ mediany akcji na
ukończony poziom przed/po na r085**.

## 3. Co jest naprawdę cenne (i to jest sporo)

1. **Uczciwość STATUS.md wprost wzorowa**: 2/4 przegranych „na czerwono, nie w przypisie",
   „RHAE 40.06 ≠ 40% LB", „NIEZWERYFIKOWANE na GPU/gatewayu". Dokładnie kultura, której
   kampania potrzebuje po epizodach v9/v10/„3,6×".
2. **Pułapka „obiekt pod graczem jest zasłonięty"** (fałszywy progres → pętla 2-krokowa;
   rozstrzygać `pending` dopiero po odejściu z pola) — uniwersalna lekcja obserwacyjna,
   kandydat do DISCOVERIES. Ten sam gatunek co „testy 6/6 przy martwej funkcji".
3. **ConvergedGuard** — ban na hashu stanu zamiast okna akcji: łapie pętle dłuższe niż okno
   (test z pętlą 6-krokową), czyszczony progiem postępu. **Najbezpieczniejszy z trzech do
   wpięcia** (additive filter po modelu, try/except-friendly).
4. **Zasada „oceniać patch jako Δ(mediana akcji/ukończony poziom)"** + bramka „jeśli Δ≤0 —
   nie wysyłać" — w 100% zgodne z PLAN-50 (przepustowość/efektywność) i naszym standardem
   smoke-GO. Najlepsze jednozdanie całej paczki.
5. Metryka labu = poprawny wzór konkursowy (patrz §1); wyniki w pełni odtwarzalne.

## 4. Ryzyka integracji z harnessem (tego w ich docs brakuje najwięcej)

| mechanizm | odpowiednik w harnesmie v13.x | konflikt? | warunek wpięcia |
|---|---|---|---|
| **PlanCache** | patch 0006 (win-path replay, **tylko frame-verified**) + playbook 14/14 | ⚠️ **TAK — filozofia** | `learn_from_episode` cache'uje WSZYSTKO (`setdefault`) → replay niezweryfikowanego planu **pali akcje** (deficytowy zasób, RHAE ~ (h/ai)²). Wpięcie TYLKO jako cache segmentów frame-verified (reuse maszynerii 0006) albo z weryfikacją klatek przy replayu |
| **BudgetLedger** | priority scheduler (priority gate + `priority_pace_reference.json`) + moje 0009 (budżet poziomu) | ⚠️ **TAK — dwa harmonogramy będą walczyć** | reguła jednego pisarza: ledger ZASTĘPUJE `pick_game`, nie dochodzi obok; dotyka servingu → to jest zmiana klasy smoke-required, nie „tania warstwa" |
| **ConvergedGuard** | dead-skip + anti-loop (okno akcji) | ✅ mało | additive filter po modelu; kill-switch env; mierzyć fałszywe banowanie (triggered/game) |

Dodatkowe: „oszczędza tokeny i akcje decyzyjne" — w prawdziwym harnessie wymiana jest
pośrednia (tokeny → tok/akcję → akcje z budżetu 2945 s); jedyny twardy koszt to AKCJE, więc
każdy błędny replay z cache działa PRZECIW metryce, którą chcemy poprawić.

## 5. Rekomendacja (i odpowiedź na ich PS)

**Zgadzam się w 90%: v18 jako „kolejny pełny kernel" — nie.** Kolejność dnia nadal:
1. **Slot 30.10**: v13.5-consensus (albo v17-naj = v13.5 + self-pace Gemmy + dormant 0010,
   jeśli trio zdąży zweryfikować 9 patchy) — to są elementy ZMIERZONE, o rozłącznych plikach.
2. **Warstwa action-efficiency = kandydat na flip 1.11**, po pomiarze Δ na r085, zgodnie z ich
   własną bramką Δ≤0.

**Na ofertę patcha `llm_policy.py` z `HarnessHook`: TAK, ale w wariantze minimalnym:**
- tylko **ConvergedGuard** (+ ewentualnie PlanCache ograniczony do frame-verified z maszynerią
  0006); **bez BudgetLedger** (kolizja z priority schedulerem — osobny eksperyment, osobny slot);
- default **OFF** (env-gated, kill-switch jedną wartością), pomiar Δ mediany akcji/poziom na
  r085 **przed** smoke, smoke przed slatem;
- patch nie może dotykać call-site solvera (standard drop-in kampanii).

**Higiena repo:** 2 pliki .py leżą w **rootie gałęzi** — do przeniesienia do `ARC3/duck-v17-action-efficiency/`
(zawartość zipa ma poprawną strukturę); rozdzielić też nazwę „warstwa" od „planner vs reactive"
w nagłówkach, żeby nie dziedziczyć luki atrybucji z §2.

## 6. Werdykt

**PRZYJĄĆ do palety jako materiał na 1.11, NIE na slot 30.10.** Paczka uczciwa, odtwarzalna,
z jedną realnie nową częścią (ConvergedGuard), jedną świetną zasadą pomiaru (Δ akcji/poziom)
i jedną znaczącą wadą prezentacji (atrybucja 40.06). Ich własna rekomendacja („nie twórzcie
v18, mierzcie Δ na r085") jest najlepszą rzeczą w całej korespondencji — i obowiązuje też
wobec nich samych.
