# 📦 HANDOFF: paczka dla innych sesji Areny (30.10.2026, ~12:00 UTC)

**Od:** sesja strategii/analizy Arena.ai (workspace `peteraangelic-pixel` — ARC).
**Dla:** wszystkich gałęzi roboczych (`arena/*`): Smak 5ed750ef, Pokemon a450/c87/7911/…,
Gemma c4eeb067. **Nie ma tu poświadczeń GitHub** — paczka do wypchnięcia przez sesję z tokenem
albo upload UI (dokładnie jak w przypadku duck-v17-action-efficiency: PUSH_INMENTS wariant A).

## 0. Co jest w środku (i po co)

| plik/katalog | co to | status |
|---|---|---|
| `arc-v16-package/` | **mój najnowszy kernel v16-naj**: `arc3-duck-v16.ipynb` (40 komórek) = certyfikowana **v13.4-unified + patch 0009 adaptacyjny budżet poziomu (DORMANT)** + metadata + patch + 16 testów + build/verify | ALL LOCAL CHECKS PASSED (24 checki + 16/16 testów); bramka trio (9 patchy na czystym r033) **pending** |
| `refs/0009-arena-self-pace.patch` | patch **self-pace Gemmy** (jedyne eskalacje działające w rerunie; `GameRun.actions_per_level` nie jest ukrywany) — referencja do kompozycji v17-naj | ich testy 7/7; u mnie niesprawdzany |
| `arc-porownanie-v16-vs-najnowsze-30-10.md` | pełne porównanie wszystkich scaleń 30.10 (mój v16 vs Smak v13.5 vs Gemma v16 vs analiza 7911) + mapa kolizji slugów | — |
| `arc-review-duck-v17-action-efficiency.md` | moja recenzja nowej paczki (warstwa action-efficiency): co zweryfikowane, **luka atrybucji 40.06**, ryzyka integracji, rekomendacja | reprodukcja: 7/7 testów, eval identyczny |
| `arc-war-room-27-10.md` | war-room kampanii (aktualizacje 27–30.10, intel, sloty) | — |

## 1. STAN WYŚCIGU — 30.10 (~12:00 UTC), zostały 3 dni (deadline 2.11)

- **Kernele gotowe (oczekują na GO ownera):** Smak **v13.5-consensus** (`arc3-duck-v13-5-consensus`,
  certyfikat 8/8 r033 + 12+6+11 testów, propozycja slotu 30.10) · Gemma **duck-v16** (9 patchy:
  8 łańcucha + 0009 self-pace; łańcuch zweryfikowany przez nią na czystym r033) · mój
  **arc3-duck-v16** (v13.4 + dormant 0009-dyn).
- **Rekomendacja** (spójna 5 sesji): slot 30.10 = **v13.5-consensus** (lub v17-naj = v13.5 +
  self-pace + mój 0009-dyn jako **0010/extra-08** — pliki rozłączne); 31.10 = powtórka/kontrola;
  1.11 = flip wg sond (uzbrojenie 0010 `LEVEL_TOKEN_CAP 0→60000`, `SELF_PACE=0`, HISTORY 150→48,
  warstwa action-efficiency po Δ); 2.11 = select best.
- **Prawdziwa dźwignia (7911): hint na openerze = 24× większa niż cały spór o eskalację**
  (spór = 2 akcje/grę; połowa efektu hinta → 266 akcji/grę ≥ 253 → 50 pkt). Bramka: `a/call ≥ 6.0`
  (leży na granicy 253; bramka 1.8 Gemmy jest nie do obalenia — najgorszy run 4.57).
- **Sufit wyniku**: `score ≤ 100 × pokrycie` (30/30); pokrycie ~29% → ~29 pkt; do 50 brakuje
  **+1,1 poziomu/grę = +22% budżetu akcji**.
- **Baseline'y UKRYTE w submisji** → eskalacja względna (0008) degeneruje do absolutnych
  20+cap2 (42 wstrzyknięcia/2,9% puli na r085); self-pace Gemmy (22/14) działa w rerunie.
- Leaderboard (audyt nowej sesji, hipoteza do odświeżenia): TOP-1 75.56, TOP-2 70.02, TOP-3 58.59.

## 2. ⚠️ HIGIENA SLUGÓW (ważne przed każdym pushem)

| slug Kaggle | kto | uwaga |
|---|---|---|
| `arc3-duck-v13-3-arena` | Smak | metadata Gemmy duck-v15 **wskazuje tu** → push nadpisze |
| `arc3-duck-v13-4-unified` | Smak | metadata Gemmy duck-v16 **wskazuje tu** → push nadpisze (wersja 2) |
| `arc3-duck-v13-5-consensus` | Smak | unikalny |
| `arc3-duck-v15` | **Pokemon (metadata)** | zajęty przez ich metadata; nie używać |
| `arc3-duck-v16` | **Arena-strategia (JA)** | wolny do wypchnięcia mojego v16-naj |

Zasada: przed pushem porównać `kernel-metadata.json` z listą własnych kerneli na Kaggle.

## 3. Co każdy może z mojego v16-naj wziąć

1. **Całość** = push `arc-v16-package/` 1:1 (`kaggle kernels push -p arc-v16-package` po
   ew. zmianie id) → **zachowanie ≡ v13.4** (0009 dormant: wymaga `static_cap > 0`), więc
   bezpieczny nawet bez smoke'a łańcucha — ale standard jest standard: 9 patchy na r033.
2. **Sam patch 0009** (`patches/0009-dyn-level-budget.patch`, 253 linie) — dotyczy WYŁĄCZNIE
   `arc3_level_budget.py` (nie dotyka tool_agent/solver/plan_commit → zero kolizji z
   0001–0008 i z self-pace Gemmy). Dokłada się jako `duck-extra-07/08` + wpisy w
   `ARC3_VARIANT` (wzór: diff kom. 1 i writera w moim notebooku). **Dormancja wbudowana**:
   przy `ARC3_LEVEL_TOKEN_CAP="0"` moduł jest inertny; uzbrojenie = jedna wartość (60000).
3. **verify_v16.py** — wzorzec weryfikacji bez bundle'a (rekonstrukcja modułu 0004 z samego
   notebooka, testy na spatchowanych bajtach, dormancja/uzbrojenie, cell-diff vs baza).

## 4. Czego tu NIE ma (uczciwie)

- Smoke'a GPU, submitów, pomiaru `a/call` po hintcie — **nic z mojego nie było na Kaggle**.
- Rozstrzygnięcia, czy roster powtarza gry (sonda nigdy nie wróciła z prawdziwego submitu).
- Weryfikacji patcha self-pace Gemmy poza jej własnymi testami.
- Przesunięcia plików nowej sesji do `ARC3/` (leżą w rootie gałęzi Smaka; zip ma dobrą strukturę).

## 5. Zasady kampanii (przypomnienie, wszyscy je już stosują)

1. Nic na Kaggle bez GO ownera; submit TYLKO klik w UI (CLI = atrapa).
2. Patch: `git apply --check` na czystym r033 + `cmp` z plikiem, na którym przeszły testy.
3. `%%writefile` zawsze z końcowym `\n` (corrupt patch trap).
4. Liczby z cudzych README = hipotezy; przeliczać na r085.
5. 1 hipoteza = 1 zgłoszenie; lokalna statystyka przed uploadem; wszystko pod writeup.

## 6. Jak to wypchnąć na GitHub (ta sesja NIE ma poświadczeń)

Sprawdzone 30.10: brak `GIT*/GH_*/TOKEN*` w env, brak `~/.netrc`/`~/.git-credentials`,
connector GitHub = unsupported. Paczka jest więc repo gotowym do pusha:

```bash
unzip arc-arena-handoff-30-10.zip && cd arc-arena-handoff-30-10
git log --oneline                      # historia już jest (1 commit)
git remote -v                          # origin -> Smak-Domu-Konkurs (zmień wg needs)
git push -u origin arena/strategia-handoff-30-10
```

Alternatywa bez git: wgraj pliki przez GitHub UI ("Add files via upload") — jak zrobiono
z 3 plikami duck-v17 (283a36b8). Gałąź docelowa wg uznania ownera; zawartość nie koliduje
z żadną ścieżką `ARC3/**` (tworzy `arc-v16-package/`, `refs/`, dokumenty .md w root).
