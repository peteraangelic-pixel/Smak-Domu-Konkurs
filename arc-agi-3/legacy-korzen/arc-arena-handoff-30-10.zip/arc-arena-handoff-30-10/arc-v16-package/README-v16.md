# 🧩 ARC3 Duck **v16-naj** — best-of-all-v15s (Arena, 30.10.2026, ~10:30 UTC)

**Kontekst:** 30.10 rano trzy gałęzie niezależnie zbudowały swoje scalenia
(Pokemon `duck-v15` 08:10, Gemma `duck-v15` 08:12, Smak `v13.4-unified` 08:15).
v16-naj = przegląd wszystkich trzech + wyciągnięcie maximum: **baza = jedyna
w pełni skodyfikowana certyfikacja (Smak 8/8 na czystym r033) + jedyny element,
którego nikt inny nie ma (Arena: adaptacyjny budżet poziomu, patch 0009)**.

## 1. Porównanie czterech scaleń (stan 30.10 ~10:30)

| element | Pokemon duck-v15 | Gemma duck-v15 | Smak v13.4-unified | **Arena v16-naj** |
|---|---|---|---|---|
| baza | v14 (= v13.2 + 20 + sondy) | v13.3-arena | v13.2+v13.3+v14 | **v13.4-unified** |
| OPENER_COMMIT_HINT=1 (batch) | ❌ | ✅ | ✅ | ✅ |
| patch 0007 replay-log | ❌ | ✅ | ✅ | ✅ |
| ESCALATE=20 (zmierzone) | ✅ | ✅ | ✅ | ✅ |
| eskalacja względna (patch) | ✅ własna 0007 | ❌ (tylko PROPOZYCJA) | ✅ **0008, w łańcuchu r033** | ✅ (Smaka, bajt-w-bajt) |
| sondy budżet+roster + guard hooka | ✅ | ✅ | ✅ (+fix: `_orig_play` w try, roster→osobny plik) | ✅ |
| **adaptacyjny budżet poziomu (0009)** | ❌ | ❌ | ❌ | ✅ **jedyny** |
| weryfikacja łańcucha | 7/7 r033 | przenosi v13.3 7/7 | **8/8 r033 + 12+6+11 testów** | lokalnie: 24 checki + 16 testów; **bramka trio: 9/9 na r033** |
| slug Kaggle | `arc3-duck-v15` ⚠️ ZAJĘTY | (metadata osobna) | `arc3-duck-v13-4-unified` | `arc3-duck-v16` |

Kluczowe intel z przeglądu (nowe, niedostępne rano):

- **Pokemon: baseline'y ukryte w submisji** — `base_actions_per_level is None`
  w trybie rerun → eskalacja względna degraduje do absolutnych 20 + cap 2/poziom
  (mierzy się lokalnie/smoke; cap działa wszędzie). Uczciwy limit dźwigni 0008.
- **Gemma: korekta Smaka** — scaffoldowy default `ARC3_HISTORY_ASSISTANT_TURNS`
  to **30**, nie 150; propozycja następnego eksperymentu 30→18 (po zmierzeniu
  `a/call`, nie teraz). Oraz mechanizm: `akcje/grę = czas / (tok/akcję × 17,2 ms)`,
  ~85% czasu akcji to generowane tokeny → batch (hint) = ta sama dźwignia co
  commit(plan), ale bez sandboxa/planu.
- **Smak: prognoza rerunu 26–31** (konwergencja 4 sesji); jedyna dźwignia >50 to
  commit(plan) (~0,3 s/akcję zamiast 12,9 → ~450 akcji/grę jeśli model słucha).

## 2. Co v16 dodaje do certyfikowanej v13.4 (dokładnie jedna rzecz)

**Patch 0009 `duck-extra-07` — adaptacyjny budżet tokenów poziomu** (Arena;
dawny 0007-dyn, przenumerowany, bo łańcuch Smaka zajął 0007/0008):

- historia ≤8 ukończonych poziomów gry → cap = **clamp(mediana×4.0, floor=
  `ARC3_LEVEL_TOKEN_CAP`, 150k)**; drabinka resetów ×1.5; ABANDON @1.5×cap po
  wyczerpanych resetach; **nigdy ostrzejszy od statycznego 0004**;
- dotyczy wyłącznie `arc3_level_budget.py` → **zero kolizji kontekstów** z
  0008 Smaka (tool_agent + solver); 0009 wstaje na module zrekonstruowanym
  z samego notebooka bazowego;
- teza: poziomy-odpady (tn36 86%, ls20 91% tokenów) oddają tokeny reszcie gry
  → więcej akcji tam, gdzie są punkty (PLAN-50: throughput).

**DORMANCJA (podwójna, przetestowana na spatchowanym module):**
v13.4 mierzyła cap 45k na **−0.4..−2.2 pkt** → w v16 `ARC3_LEVEL_TOKEN_CAP="0"`
(stan v13.4, bez zmian), a `LevelBudget` jest inertny gdy `static_cap == 0`.
**Zachowanie domyślne v16 ≡ v13.4-unified.** Uzbrojenie = JEDNA wartość:
`"ARC3_LEVEL_TOKEN_CAP": "60000"` (kandydat na flip 1.11 wg sondażu budżetu).
Kill-switch: `"ARC3_DYN_CAP": "0"` = dokładna semantyka statyczna 0004.

## 3. Status weryfikacji (uczciwie)

**Lokalnie (ALL LOCAL CHECKS PASSED, 24/24 + 16/16 testów):** struktura 40
komórek; embedded 0009 == plik pakietu bajt-w-bajt; base integrity (embedded
extra-06 == opublikowany patch 0008 Smaka); kompilacja czystych komórek;
**cell-diff vs baza = wyłącznie kom. 1 (rejestr), kom. 2 (banner+komentarz),
nowy writer 14** — reszta bajt-w-bajt; 0009 aplikuje się `git apply` na
rekonstrukcji 0004 z bazy i kompiluje; dormancja/uzbrojenie/kill-switch na
spatchowanych bajtach; 16 testów dyn-budget.

**NIE zrobione (brama trio, standard v13.4):** `git apply` pełnego łańcucha
**9 patchy** na czystym **r033** + smoke A/B + recenzja + GO usera. Ryzyko
niskie (0009 dotyka pliku, którego nie dotyka żaden z 8 patchy), ale standard
jest standard.

## 4. Pliki

| plik | rola |
|---|---|
| `arc3-duck-v16.ipynb` | zbudowany notebook (40 komórek, 749,222 B) |
| `kernel-metadata-v16.json` | push: `petersharps/arc3-duck-v16` |
| `base_v13_4_unified.ipynb` | baza = Smak v13.4-unified (trwała kopia) |
| `patches/0009-dyn-level-budget.patch` | adaptacyjny budżet (253 linie) |
| `patches_ref/0008-arena-escalate-relative.patch` | referencja Smaka (check base integrity) |
| `src/arc3_level_budget_v13_2.py` | moduł polityki 0009 (standalone) |
| `tests/test_arc3_dyn_budget.py` | 16 testów czystej logiki |
| `tools/build_v16.py` / `tools/verify_v16.py` | build + lokalne bramki |

## 5. Checklista trio przed wysyłką

- [ ] `git apply --check` pełnego łańcucha **9 patchy** na czystym r033
      (0001→0009; 0009 po 0008, plik bez kolizji).
- [ ] Smoke A/B: v13.4 vs v16 (`ARC3_DYN_CAP` i tak nie zmienia zachowania przy
      cap=0 → smoke ma potwierdzić **identyczność** i brak crasha writera).
- [ ] Log musi pokazać: `v16-naj profile=plan … escalate=20`, env z
      `'ARC3_DYN_CAP': '1', 'ARC3_LEVEL_TOKEN_CAP': '0'`,
      `ARC3 extra patch applied: …-07.patch`, `v13.4 budget: …`, obie sondy.
- [ ] GO usera → `kaggle kernels push -p <dir>` → **Submit to Competition w UI**
      (CLI = atrapa 0.0).

## 6. Rekomendacja slotów (dekidingo — GO usera; spójna z propozycją Smaka)

| slot | co | dlaczego |
|---|---|---|
| **30.10** | **v16-naj** (≡ v13.4 + dorman 0009) | maksimum zmierzonych dźwigni + pełna obserwowalność; zero nowych zachowań względem v13.4 |
| **31.10** | powtórka v16-naj (draw) **lub** v14-Gemma jako kontrola absolutna @20 | czysta atrybucja vs redukcja wariancji |
| **1.11** | flip wg meteringu: `ARC3_LEVEL_TOKEN_CAP 0→60000` (uzbrojenie 0009) jeśli sonda budżetu pokaże głodzenie / RELATIVE=0 → v14-exact / HISTORY 30→18 (Gemma) | pierwszy dzień z uzbrojonym 0009 = jedyna niezmierzona dźwignia głębi |
| **2.11** | select best (sprawdzić w rules liczbę punktowanych submisji) | — |

⚠️ **Kolizja slugów:** Pokemon wydał `petersharps/arc3-duck-v15` w swoim
metadata. Nie pushować żadnego starego pakietu „v15" bez sprawdzenia — pod tym
slugem może wylądować ich notebook. v16 unika konfliktu z założenia.
