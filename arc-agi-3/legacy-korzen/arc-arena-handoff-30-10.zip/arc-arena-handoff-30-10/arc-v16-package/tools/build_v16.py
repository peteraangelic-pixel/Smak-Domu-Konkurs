#!/usr/bin/env python3
"""Build `arc3-duck-v16.ipynb` from the certified duck-v13-4-unified notebook.

Base: arena/5ed750ef-smak-domu-konkurs `arc-agi-3/duck-v13-4-unified/arc3-duck-v13.ipynb`
(39 cells; ALL CHECKS PASSED: 8/8 patches on clean r033, 12 plan-commit +
6 escalate-relative + 11 winpath on the patched tree, probes on stubs,
playbook byte-identical 14/14 on the engine, serving parity kom.21==22).

v13.4-unified already contains (nothing for us to rebuild):
  v13.2 base + ARC3_OPENER_COMMIT_HINT=1 + patch 0007-arena-replay-log +
  ESCALATE_ACTIONS=20 + patch 0008-arena-escalate-relative (relative
  escalation, engine-chain-verified) + guarded c45 probe hook + budget and
  roster probes.

v16-naj adds exactly ONE thing — Arena's adaptive per-level token budget
(the old 0007-dyn, renumbered to 0009 because Smak's chain took 0007/0008):

1. NEW patch 0009 (duck-extra-07): median completed-level cost x4 clamped
   [floor=ARC3_LEVEL_TOKEN_CAP, 150k], reset ladder x1.5, patient abandon
   at 1.5x after exhausted resets; never stricter than static 0004;
   ARC3_DYN_CAP=0 -> exact static semantics.
2. Variant env: keep ARC3_LEVEL_TOKEN_CAP="0" (v13.4 measured -0.4..-2.2 at
   45k -> cap stays OFF) + explicit "ARC3_DYN_CAP": "1". Dormancy is doubled:
   LevelBudget is inert whenever static_cap == 0, so v16 default behaviour ==
   v13.4 byte-for-byte. Arming = ONE value: ARC3_LEVEL_TOKEN_CAP 0 -> 60000.
3. Variant name -> v16-naj; switch banner -> v16-naj; one writer cell
   (extra-07) after Smak's extra-06 writer.

Everything else stays byte-identical to v13.4-unified.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
MARK_BASE_CELLS = 39  # duck-v13-4-unified has exactly 39 cells


def cell_source(cell: dict) -> str:
    return "".join(cell.get("source", []))


def set_source(cell: dict, text: str) -> None:
    cell["source"] = text.splitlines(keepends=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=str(PKG / "base_v13_4_unified.ipynb"))
    ap.add_argument("--p9", default=str(PKG / "patches" / "0009-dyn-level-budget.patch"))
    ap.add_argument("--out", default=str(PKG / "arc3-duck-v16.ipynb"))
    args = ap.parse_args()

    nb = json.loads(Path(args.base).read_text())
    cells = nb["cells"]
    assert len(cells) == MARK_BASE_CELLS, f"base has {len(cells)} cells, expected {MARK_BASE_CELLS}"

    p9 = Path(args.p9).read_text()
    if not p9.endswith("\n"):
        p9 += "\n"

    # 1. switch cell: banner only. ESCALATE stays 20 (v13.4 measurement).
    switch_idx = next(i for i, c in enumerate(cells)
                      if "PLAN_COMMIT" in cell_source(c) and "ESCALATE_ACTIONS" in cell_source(c))
    src = cell_source(cells[switch_idx])
    src, n = re.subn(r"v13\.4-unified profile=", "v16-naj profile=", src, count=1)
    assert n == 1, "banner anchor not found in switch cell"
    marker = "# v16-naj additions (Arena): patch 0009 duck-extra-07 — adaptive per-level\n"
    marker += (
        "# token budget (median completed-level cost x4 in [LEVEL_TOKEN_CAP,150k], reset\n"
        "# ladder x1.5, patient abandon 1.5x). DORMANT: ARC3_LEVEL_TOKEN_CAP=\"0\" keeps the\n"
        "# whole feature off (LevelBudget requires static_cap > 0), so default behaviour ==\n"
        "# v13.4-unified. Arm with ONE value: \"ARC3_LEVEL_TOKEN_CAP\": \"60000\". Kill switch:\n"
        "# \"ARC3_DYN_CAP\": \"0\" -> exact static 0004 semantics. 16 offline unit tests.\n"
    )
    src = src.replace("import os as _v11_os\n", marker + "import os as _v11_os\n", 1)
    assert marker.splitlines()[0] in src, "switch comment insert failed"
    set_source(cells[switch_idx], src)

    # 2. variant cell: register extra-07 + 0009, explicit dyn flag, rename.
    variant_idx = next(i for i, c in enumerate(cells) if "ARC3_VARIANT = {" in cell_source(c))
    src = cell_source(cells[variant_idx])
    src, n = re.subn(r'("/kaggle/duck-extra-06\.patch")(\s*\])',
                     r'\1, "/kaggle/duck-extra-07.patch"\2', src, count=1)
    assert n == 1, "patch_files anchor not found"
    src, n = re.subn(r'("0008-arena-escalate-relative\.patch")(\s*\])',
                     r'\1, "0009-dyn-level-budget.patch"\2', src, count=1)
    assert n == 1, "patches anchor not found"
    src, n = re.subn(r'("ARC3_LEVEL_TOKEN_CAP": )"0"',
                     r'\1"0", "ARC3_DYN_CAP": "1"', src, count=1)
    assert n == 1, "cap anchor not found"
    src, n = re.subn(r'"name": "[^"]*"', '"name": "v16-naj"', src, count=1)
    assert n == 1, "variant name anchor not found"
    set_source(cells[variant_idx], src)

    # 3. one writer cell right after Smak's extra-06 writer.
    write_idx = max(i for i, c in enumerate(cells)
                    if "duck-extra-06.patch" in cell_source(c) and "write_text" in cell_source(c))
    writer = (
        "# ARC3 Duck v16-naj: patch 0009-dyn-level-budget — adaptacyjny budżet tokenów\n"
        "# poziomu (Arena; dawny 0007-dyn, przenumerowany — 0007/0008 zajęte przez łańcuch\n"
        "# v13.3/v13.4). Historia ≤8 ukończonych poziomów; cap = clamp(mediana×4,\n"
        "# floor=ARC3_LEVEL_TOKEN_CAP, 150k); drabinka resetów ×1.5; ABANDON @1.5×cap po\n"
        "# wyczerpanych resetach; nigdy ostrzejszy od statycznego 0004. DORMANT przy\n"
        "# ARC3_LEVEL_TOKEN_CAP=\"0\" (LevelBudget wymaga static_cap > 0) — zachowanie\n"
        "# domyślne identyczne z v13.4-unified. Uzbrojenie jedną wartością: cap 0→60000.\n"
        "# Kill-switch: ARC3_DYN_CAP=\"0\" = dokładna semantyka statyczna 0004. 16 testów.\n"
        "from pathlib import Path as _P\n"
        '_P("/kaggle/duck-extra-07.patch").write_text(' + repr(p9) + ")\n"
    )
    cells.insert(write_idx + 1, {
        "cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [],
        "source": writer.splitlines(keepends=True),
    })

    out = Path(args.out)
    out.write_text(json.dumps(nb, indent=1, ensure_ascii=False) + "\n")
    print(f"built {out} ({len(cells)} cells, {out.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
