#!/usr/bin/env python3
"""Verify the v16-naj package WITHOUT the r033 bundle.

A. structure (40 cells, banner, env, patch lists, ESCALATE=20 unchanged,
   cap OFF + explicit ARC3_DYN_CAP=1 -> v16 default behaviour == v13.4)
B. embedded extra-07 == package 0009; base integrity: base notebook's
   embedded extra-06 == Smak's published 0008-arena-escalate-relative.patch
C. every pure-python cell compiles (IPython-isms skipped)
D. cell-level identity vs base: ONLY cells 1, 2 differ, ONLY by the
   documented substitutions; writer inserted at 14; 15..39 == 14..38
E. 0009 applies to the 0004 module reconstructed FROM THE BASE NOTEBOOK;
   patched module compiles; 16 dyn-budget tests run on those exact bytes;
   dormancy (cap=0 -> off) and arming (cap=60000 -> dyn on) hold on the
   patched module
F. full local suite (dyn budget) on src copies

Exit 0 = all local checks pass. The full 9-patch chain on a pristine r033
bundle remains the trio's gate (same standard as v13.4-unified's 8/8).
"""
from __future__ import annotations

import argparse
import ast
import json
import py_compile
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))


def cells_of(nb: dict) -> list[str]:
    return ["".join(c.get("source", [])) for c in nb["cells"] if c.get("cell_type") == "code"]


def all_cells(nb: dict) -> list[str]:
    return ["".join(c.get("source", [])) for c in nb["cells"]]


def check(name: str, ok: bool, detail: object = "") -> bool:
    print(f"[{'OK' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail and not ok else ""))
    return ok


def first_write_text_arg(src: str) -> str:
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "attr", "") == "write_text":
            return ast.literal_eval(node.args[0])
    raise AssertionError("no write_text call in cell")


def extract_0004_module(base_nb: dict) -> str:
    for src in cells_of(base_nb):
        if "/kaggle/duck-extra-02.patch" not in src or "write_text" not in src:
            continue
        text = first_write_text_arg(src)
        idx = text.find("diff --git a/ARC3-Inference/inference/framework/arc3_level_budget.py")
        assert idx >= 0, "0004 section not found"
        nxt = text.find("diff --git", idx + 10)
        section = text[idx:nxt if nxt > 0 else len(text)]
        out, in_hunk = [], False
        for line in section.splitlines():
            if not in_hunk:
                if line.startswith("@@ -0,0"):
                    in_hunk = True
                continue
            if line.startswith("+") and not line.startswith("+++"):
                out.append(line[1:])
            elif line.startswith("\\"):
                continue
            else:
                raise AssertionError(f"unexpected line in new-file hunk: {line[:60]!r}")
        return "\n".join(out) + "\n"
    raise AssertionError("0004 writer cell not found")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--built", default=str(PKG / "arc3-duck-v16.ipynb"))
    ap.add_argument("--base", default=str(PKG / "base_v13_4_unified.ipynb"))
    ap.add_argument("--p8-ref", default=str(PKG / "patches_ref" / "0008-arena-escalate-relative.patch"))
    ap.add_argument("--p9", default=str(PKG / "patches" / "0009-dyn-level-budget.patch"))
    ap.add_argument("--skip-tests", action="store_true")
    args = ap.parse_args()

    ok = True
    nb = json.loads(Path(args.built).read_text())
    base_nb = json.loads(Path(args.base).read_text())
    built = all_cells(nb)
    base = all_cells(base_nb)
    cells = cells_of(nb)

    # A. structure ----------------------------------------------------------
    ok &= check("notebook has 40 cells", len(nb["cells"]) == 40, f"got {len(nb['cells'])}")
    ok &= check("v16-naj banner in switch", any("v16-naj" in s and "profile" in s for s in cells))
    variant = next(s for s in cells if "ARC3_VARIANT = {" in s)
    ok &= check("variant name v16-naj", '"name": "v16-naj"' in variant)
    ok &= check("extra-07 in patch_files", '"/kaggle/duck-extra-07.patch"' in variant)
    ok &= check("0009 in patches list", '"0009-dyn-level-budget.patch"' in variant)
    ok &= check("v13.4 chain intact in lists (0007-arena + 0008-arena)",
                '"0007-arena-replay-log.patch"' in variant
                and '"0008-arena-escalate-relative.patch"' in variant)
    ok &= check("cap stays OFF (0) + explicit dyn flag",
                '"ARC3_LEVEL_TOKEN_CAP": "0"' in variant and '"ARC3_DYN_CAP": "1"' in variant)
    ok &= check("v13.4 levers intact (RELATIVE=1, RATE=1.2, MAX_PER_LEVEL=2, OPENER=1)",
                '"ARC3_ESCALATE_RELATIVE": "1"' in variant
                and '"ARC3_ESCALATE_RATE": "1.2"' in variant
                and '"ARC3_ESCALATE_MAX_PER_LEVEL": "2"' in variant
                and '"ARC3_OPENER_COMMIT_HINT": "1"' in variant)
    switch = next(s for s in cells if "ESCALATE_ACTIONS" in s and "PLAN_COMMIT" in s)
    ok &= check("ESCALATE_ACTIONS = 20 (unchanged)", re.search(r"ESCALATE_ACTIONS\s*=\s*20\b", switch) is not None)

    # B. embedded patches byte-identical -------------------------------------
    w7 = next(s for s in cells if "duck-extra-07.patch" in s and "write_text" in s)
    ok &= check("embedded 0009 == package patch", first_write_text_arg(w7) == Path(args.p9).read_text())
    base_w6 = next(s for s in cells_of(base_nb) if "duck-extra-06.patch" in s and "write_text" in s)
    ok &= check("base integrity: embedded extra-06 == Smak's published 0008",
                first_write_text_arg(base_w6) == Path(args.p8_ref).read_text())

    # C. pure-python cells compile -------------------------------------------
    skipped = 0
    for i, src in enumerate(cells):
        lines = src.splitlines(keepends=True)
        body = "".join(lines[1:]) if lines and lines[0].startswith("%%") else src
        ipython = ((lines and lines[0].startswith("%%"))
                   or any(l.lstrip().startswith("!") for l in lines)
                   or re.search(r"^\s*await\s+", body, re.M) is not None
                   or ("diff --git" in body and "write_text" not in body))
        try:
            compile(body, f"<cell {i}>", "exec")
        except SyntaxError as exc:
            if ipython:
                skipped += 1
                continue
            ok &= check(f"cell {i} compiles", False, repr(exc))
    ok &= check("pure-python cells compile", True, f"{skipped} skipped")

    # D. cell-level identity vs base ------------------------------------------
    ok &= check("cells 0 identical (markdown)", built[0] == base[0])
    ok &= check("cells 3..13 identical", all(built[i] == base[i] for i in range(3, 14)))
    ok &= check("cells 15..39 == base 14..38 (pure shift)",
                all(built[i] == base[i - 1] for i in range(15, 40)))
    reverted = built[1].replace('"ARC3_LEVEL_TOKEN_CAP": "0", "ARC3_DYN_CAP": "1"',
                                '"ARC3_LEVEL_TOKEN_CAP": "0"')
    reverted = reverted.replace(', "/kaggle/duck-extra-07.patch"', "")
    reverted = reverted.replace(', "0009-dyn-level-budget.patch"', "")
    reverted = re.sub(r'"name": "v16-naj"', '"name": "v13-4-unified"', reverted, count=1)
    ok &= check("cell 1 differs ONLY by documented substitutions", reverted == base[1])
    reverted2 = built[2].replace("v16-naj profile=", "v13.4-unified profile=")
    start = reverted2.find("# v16-naj additions (Arena):")
    end = reverted2.find("import os as _v11_os")
    if start >= 0 and end > start:
        reverted2 = reverted2[:start] + reverted2[end:]
    ok &= check("cell 2 differs ONLY by banner + comment block", reverted2 == base[2])

    # E. 0009 on the reconstructed 0004 module + tests on patched bytes -------
    old_module = extract_0004_module(base_nb)
    with tempfile.TemporaryDirectory() as tmp:
        tree = Path(tmp) / "ARC3-Inference" / "inference" / "framework"
        tree.mkdir(parents=True)
        target = tree / "arc3_level_budget.py"
        target.write_text(old_module)
        rc = subprocess.run(["git", "apply", "--check", str(Path(args.p9).resolve())],
                            cwd=tmp, capture_output=True, text=True)
        ok &= check("0009 applies to reconstructed 0004 module (from v13.4 base)",
                    rc.returncode == 0, rc.stderr[:300])
        subprocess.run(["git", "apply", str(Path(args.p9).resolve())], cwd=tmp, check=True)
        try:
            py_compile.compile(str(target), doraise=True)
            ok &= check("patched module py_compiles", True)
        except py_compile.PyCompileError as exc:
            ok &= check("patched module py_compiles", False, str(exc)[:300])
        if not args.skip_tests:
            import importlib.util
            spec = importlib.util.spec_from_file_location("patched_budget", target)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            # dormancy / arming on the PATCHED module
            import os
            saved = {k: os.environ.get(k) for k in ("ARC3_LEVEL_TOKEN_CAP", "ARC3_DYN_CAP")}
            for k in ("ARC3_LEVEL_TOKEN_CAP", "ARC3_DYN_CAP"):
                os.environ.pop(k, None)
            try:
                os.environ["ARC3_LEVEL_TOKEN_CAP"] = "0"
                b_off = mod.LevelBudget.from_env()
                ok &= check("dormant with cap=0 (default behaviour == v13.4)",
                            not getattr(b_off, "dyn_enabled", True))
                os.environ["ARC3_LEVEL_TOKEN_CAP"] = "60000"
                b_on = mod.LevelBudget.from_env()
                ok &= check("armed with cap=60000 (one value)",
                            bool(getattr(b_on, "dyn_enabled", False))
                            and int(getattr(b_on, "static_cap", 0)) == 60000)
                os.environ["ARC3_DYN_CAP"] = "0"
                b_kill = mod.LevelBudget.from_env()
                ok &= check("kill-switch ARC3_DYN_CAP=0 -> exact static",
                            not getattr(b_kill, "dyn_enabled", True))
            finally:
                for k, v in saved.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v

            import tests.test_arc3_dyn_budget as t
            saved_t = (t.LevelBudget, t.KEEP_GOING, t.RESET_LEVEL, t.ABANDON)
            t.LevelBudget, t.KEEP_GOING = mod.LevelBudget, mod.KEEP_GOING
            t.RESET_LEVEL, t.ABANDON = mod.RESET_LEVEL, mod.ABANDON
            suite = unittest.defaultTestLoader.loadTestsFromModule(t)
            result = unittest.TextTestRunner(verbosity=0).run(suite)
            t.LevelBudget, t.KEEP_GOING, t.RESET_LEVEL, t.ABANDON = saved_t
            ok &= check("dyn-budget tests on PATCHED bytes", result.wasSuccessful(),
                        f"{len(result.failures)+len(result.errors)} problems")

    # F. full local suite on src copies ---------------------------------------
    if not args.skip_tests:
        rc = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests",
                             "-p", "test_*.py"], cwd=str(PKG), capture_output=True, text=True)
        tail = (rc.stderr.strip().splitlines() or [""])[-1]
        ok &= check("local suite (src copies)", rc.returncode == 0, tail)

    print("\nALL LOCAL CHECKS PASSED" if ok else "\nLOCAL CHECKS FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
