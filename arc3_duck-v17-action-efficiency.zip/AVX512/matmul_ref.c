// Ile REALNIE zyskuje program na Zen3-klasowym CPU (AVX2+FMA), bez zadnego AVX-512?
// Matmul f32 1024x1024, 4 wersje: naiwna -> blokowana -> AVX2+FMA+blokowana -> + watki
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <immintrin.h>
#ifdef _OPENMP
#include <omp.h>
#endif

static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static inline uint64_t rng(uint64_t*s){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;return *s;}

#define N 1024
static float A[N][N], B[N][N], C[N][N], C2[N][N];

// 1) naiwna, i-j-k (najgorszy mozliwy uklad dla cache)
void mm_naive(void){
    for(int i=0;i<N;i++) for(int j=0;j<N;j++){
        float s=0; for(int k=0;k<N;k++) s+=A[i][k]*B[k][j]; C[i][j]=s;
    }
}
// 2) blokowana 3x (i-k-j + kafelki L1/L2)
#define BM 64
void mm_blocked(void){
    memset(C2,0,sizeof(C2));
    for(int ii=0;ii<N;ii+=BM) for(int kk=0;kk<N;kk+=BM) for(int jj=0;jj<N;jj+=BM)
        for(int i=ii;i<ii+BM;i++) for(int k=kk;k<kk+BM;k++){
            float a=A[i][k];
            for(int j=jj;j<jj+BM;j++) C2[i][j]+=a*B[k][j];
        }
}
// 3) AVX2 + FMA + blokowanie (rdzen jak w OpenBLAS)
#define MB 96
void mm_avx2(void){
    memset(C2,0,sizeof(C2));
#pragma omp parallel for schedule(static)
    for(int ii=0;ii<N;ii+=MB){
    for(int kk=0;kk<N;kk+=MB) for(int jj=0;jj<N;jj+=MB){
        int imax=(ii+MB<N)?ii+MB:N, kmax=(kk+MB<N)?kk+MB:N, jmax=(jj+MB<N)?jj+MB:N;
        for(int i=ii;i<imax;i++) for(int k=kk;k<kmax;k++){
            float a=A[i][k];
            __m256 av=_mm256_set1_ps(a);
            int j=jj;
            for(;j+32<=jmax;j+=32){
                __m256 c0=_mm256_loadu_ps(&C2[i][j]);
                __m256 c1=_mm256_loadu_ps(&C2[i][j+8]);
                __m256 c2=_mm256_loadu_ps(&C2[i][j+16]);
                __m256 c3=_mm256_loadu_ps(&C2[i][j+24]);
                c0=_mm256_fmadd_ps(av,_mm256_loadu_ps(&B[k][j]),c0);
                c1=_mm256_fmadd_ps(av,_mm256_loadu_ps(&B[k][j+8]),c1);
                c2=_mm256_fmadd_ps(av,_mm256_loadu_ps(&B[k][j+16]),c2);
                c3=_mm256_fmadd_ps(av,_mm256_loadu_ps(&B[k][j+24]),c3);
                _mm256_storeu_ps(&C2[i][j],c0); _mm256_storeu_ps(&C2[i][j+8],c1);
                _mm256_storeu_ps(&C2[i][j+16],c2); _mm256_storeu_ps(&C2[i][j+24],c3);
            }
            for(;j<jmax;j++) C2[i][j]+=a*B[k][j];
        }
    }
}
}
double chk(void){ // suma kontrolna: gdzie wynik sie rozjechal (C vs C2)
    double s=0, s2=0;
    for(int i=0;i<N;i+=97) for(int j=0;j<N;j+=89){ s+=C[i][j]; s2+=C2[i][j]; }
    return (s-s2)/(s?s:1);
}

int main(int argc,char**argv){
    uint64_t sd=7;
    for(int i=0;i<N;i++) for(int j=0;j<N;j++){
        A[i][j]=(rng(&sd)%1000)/1000.0f-0.5f; B[i][j]=(rng(&sd)%1000)/1000.0f-0.5f; }
    double flops=2.0*N*N*N;
    double t;

    t=now(); mm_naive();   double t_n=now()-t; double r_n=chk();
    t=now(); mm_blocked(); double t_b=now()-t; double r_b=chk();
    t=now(); mm_avx2();    double t_a=now()-t; double r_a=chk();

    printf("1. naiwna i-j-k           : %7.3f s  %7.2f GFLOP/s  (ref)\n", t_n, flops/t_n/1e9);
    printf("2. + blokowanie cache    : %7.3f s  %7.2f GFLOP/s  x%.2f\n", t_b, flops/t_b/1e9, t_n/t_b);
    printf("3. + AVX2/FMA + bloki    : %7.3f s  %7.2f GFLOP/s  x%.2f\n", t_a, flops/t_a/1e9, t_n/t_a);
    printf("   (bledy zaokraglen: %.2e / %.2e)\n", r_b, r_a);
#ifdef _OPENMP
    for(int nt=1; nt<=omp_get_max_threads(); nt*=2){
        omp_set_num_threads(nt);
        memset(C2,0,sizeof(C2));
        t=now(); mm_avx2(); double tm=now()-t;   // mm_avx2 jest watkowane przez #pragma
        printf("4. + %d watkow (OpenMP)   : %7.3f s  %7.2f GFLOP/s  x%.2f\n", nt, tm, flops/tm/1e9, t_n/tm);
    }
#endif
    return 0;
}
