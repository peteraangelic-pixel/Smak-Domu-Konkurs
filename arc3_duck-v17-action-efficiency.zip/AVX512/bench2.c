// Jawny kod intrinsics: dokladnie ta sama praca, raz 256-bit, raz 512-bit.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <immintrin.h>

static double now(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static inline uint64_t rng(uint64_t *s){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;return *s;}

#if defined(USE_AVX512)
  #define VW 16
  typedef __m512 V;
  static inline V vload(const float*p){return _mm512_load_ps(p);}
  static inline V vfma(V a,V b,V c){return _mm512_fmadd_ps(a,b,c);}
  static inline V vadd(V a,V b){return _mm512_add_ps(a,b);}
  static inline float hsum(V v){return _mm512_reduce_add_ps(v);}
  #define SPREAD 16   // 32 rejestry zmm -> wiecej rownoleglych lancuchow
#else
  #define VW 8
  typedef __m256 V;
  static inline V vload(const float*p){return _mm256_load_ps(p);}
  static inline V vfma(V a,V b,V c){return _mm256_fmadd_ps(a,b,c);}
  static inline V vadd(V a,V b){return _mm256_add_ps(a,b);}
  static inline float hsum(V v){
      __m128 lo=_mm256_castps256_ps128(v), hi=_mm256_extractf128_ps(v,1);
      lo=_mm_add_ps(lo,hi); lo=_mm_hadd_ps(lo,lo); lo=_mm_hadd_ps(lo,lo);
      return _mm_cvtss_f32(lo);
  }
  #define SPREAD 8
#endif

// ---------- A: czysta przepustowosc FMA, dane w L1 ----------
// 8 niezaleznych akumulatorow x SPREAD "sladow"
__attribute__((noinline))
float kA(const float *a, int iters) {
    V acc[8];
    for (int i = 0; i < 8; i++) acc[i] = vload(a + i * VW);
    for (int it = 0; it < iters; it++) {
        for (int i = 0; i < 8; i++) acc[i] = vfma(acc[i], vload(a + 8 * VW), vload(a + 16 * VW));
    }
    V s = acc[0];
    for (int i = 1; i < 8; i++) s = vadd(s, acc[i]);
    return hsum(s);
}

// ---------- B: filtrowanie warunkowe (maski) ----------
// sumuj tylko elementy > prog: AVX-512 ma maski sprzetowo
__attribute__((noinline))
float kB(const float *a, int n, float thr) {
#if defined(USE_AVX512)
    __m512 thrv = _mm512_set1_ps(thr), s = _mm512_setzero_ps();
    for (int i = 0; i < n; i += 16) {
        __m512 v = _mm512_loadu_ps(a + i);
        __mmask16 k = _mm512_cmp_ps_mask(v, thrv, _CMP_GT_OQ);
        s = _mm512_mask_add_ps(s, k, s, v);
    }
    return _mm512_reduce_add_ps(s);
#else
    __m256 thrv = _mm256_set1_ps(thr), s = _mm256_setzero_ps();
    for (int i = 0; i < n; i += 8) {
        __m256 v = _mm256_loadu_ps(a + i);
        __m256 k = _mm256_cmp_ps(v, thrv, _CMP_GT_OQ);
        s = _mm256_add_ps(s, _mm256_and_ps(v, k)); // blend zamiast maski
    }
    return hsum(s);
#endif
}

// ---------- C: krotkie, niepodzielne przez szerokosc wiersze ----------
// typowe w DSP/grafice: 37 elementow, 1000 wierszy
__attribute__((noinline))
float kC(const float *a, int rows, int len) {
    float tot = 0;
#if defined(USE_AVX512)
    for (int r = 0; r < rows; r++) {
        const float *p = a + r * len;
        __m512 s = _mm512_setzero_ps();
        int i = 0;
        for (; i + 16 <= len; i += 16) s = _mm512_fmadd_ps(_mm512_loadu_ps(p+i), _mm512_loadu_ps(p+i), s);
        if (i < len) {  // AVX-512: jedna maskowana iteracja, zero petli ogonowej
            __mmask16 k = (__mmask16)((1u << (len - i)) - 1);
            s = _mm512_mask3_fmadd_ps(_mm512_maskz_loadu_ps(k, p+i), _mm512_maskz_loadu_ps(k, p+i), s, k);
        }
        tot += _mm512_reduce_add_ps(s);
    }
#else
    for (int r = 0; r < rows; r++) {
        const float *p = a + r * len;
        __m256 s = _mm256_setzero_ps();
        int i = 0;
        for (; i + 8 <= len; i += 8) s = _mm256_fmadd_ps(_mm256_loadu_ps(p+i), _mm256_loadu_ps(p+i), s);
        float tail[8] = {0};
        for (int j = 0; i + j < len; j++) tail[j] = p[i+j];
        s = _mm256_fmadd_ps(_mm256_loadu_ps(tail), _mm256_loadu_ps(tail), s);
        tot += hsum(s);
    }
#endif
    return tot;
}

int main(void) {
    uint64_t seed = 1234567;
    const int ITERS = 6000000;
    float *a = aligned_alloc(64, sizeof(float) * 512);
    for (int i = 0; i < 512; i++) a[i] = (float)(rng(&seed) % 100) / 100.0f;

    const int NB = 8192;
    float *b = aligned_alloc(64, sizeof(float) * NB);
    for (int i = 0; i < NB; i++) b[i] = ((int)(rng(&seed) % 2000) - 1000) / 1000.0f;

    const int ROWS = 100000, LEN = 37;
    float *c = aligned_alloc(64, sizeof(float) * ROWS * LEN);
    for (int i = 0; i < ROWS * LEN; i++) c[i] = (rng(&seed) % 100) / 100.0f;

    volatile float sink;
    double t;

    sink = kA(a, ITERS/10); sink = kB(b, NB, 0.2f); sink = kC(c, ROWS/10, LEN);

    t = now(); sink = kA(a, ITERS);            double tA = now() - t;
    t = now();
    for (int r = 0; r < 30000; r++) sink = kB(b, NB, 0.2f);
    double tB = now() - t;
    t = now();
    for (int r = 0; r < 40; r++) { sink = kC(c, ROWS, LEN); sink = kC(c, ROWS/2, LEN); }
    double tC = now() - t;

    printf("A fma_L1_throughput  : %8.3f ms  (%.2f GFLOP/s)\n", tA*1e3, 2.0*ITERS*8.0*VW/SPREAD/tA/1e9);
    printf("B masked_filter      : %8.3f ms\n", tB*1e3);
    printf("C short_rows_tails   : %8.3f ms\n", tC*1e3);
    return 0;
}
