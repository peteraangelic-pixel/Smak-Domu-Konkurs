// Ile kosztuje NAJLEPSZA MOZLIWA emulacja 512 bitow na AVX2?
// v512 = struktura dwoch __m256. To jest Dolny Poziom Kosztu (best case),
// jaki moglby osiagnac dowolny translator AVX-512 -> AVX2.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <immintrin.h>

static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static inline uint64_t rng(uint64_t*s){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;return *s;}

typedef struct { __m256 lo, hi; } v512;
static inline v512 vfma512(v512 a, v512 b, v512 c){
    v512 r; r.lo=_mm256_fmadd_ps(a.lo,b.lo,c.lo); r.hi=_mm256_fmadd_ps(a.hi,b.hi,c.hi); return r;
}
static inline v512 vadd512(v512 a, v512 b){
    v512 r; r.lo=_mm256_add_ps(a.lo,b.lo); r.hi=_mm256_add_ps(a.hi,b.hi); return r;
}
static inline float hsum256(__m256 v){
    __m128 lo=_mm256_castps256_ps128(v), hi=_mm256_extractf128_ps(v,1);
    lo=_mm_add_ps(lo,hi); lo=_mm_hadd_ps(lo,lo); lo=_mm_hadd_ps(lo,lo);
    return _mm_cvtss_f32(lo);
}

// A_w: 8 lancuchow FMA, 256-bit native  vs  A_e: to samo "512-bit" emulowane
__attribute__((noinline)) float A_w(const float*a,int it){
    __m256 acc[8]; for(int i=0;i<8;i++) acc[i]=_mm256_load_ps(a+i*8);
    for(int k=0;k<it;k++) for(int i=0;i<8;i++)
        acc[i]=_mm256_fmadd_ps(acc[i],_mm256_load_ps(a+64),_mm256_load_ps(a+128));
    __m256 s=acc[0]; for(int i=1;i<8;i++) s=_mm256_add_ps(s,acc[i]); return hsum256(s);
}
__attribute__((noinline)) float A_e(const float*a,int it){
    v512 acc[8]; for(int i=0;i<8;i++){acc[i].lo=_mm256_load_ps(a+i*16);acc[i].hi=_mm256_load_ps(a+i*16+8);}
    for(int k=0;k<it;k++) for(int i=0;i<8;i++){
        v512 m,b2; m.lo=_mm256_load_ps(a+128);m.hi=_mm256_load_ps(a+136);
        b2.lo=_mm256_load_ps(a+256);b2.hi=_mm256_load_ps(a+264);
        acc[i]=vfma512(acc[i],m,b2);
    }
    v512 s=acc[0]; for(int i=1;i<8;i++) s=vadd512(s,acc[i]);
    return hsum256(s.lo)+hsum256(s.hi);
}

// B: filtrowanie warunkowe - maska sprzetowa 512-bit vs emulacja (blend 2x + testb)
__attribute__((noinline)) float B_w(const float*a,int n,float thr){
    __m256 t=_mm256_set1_ps(thr), s=_mm256_setzero_ps();
    for(int i=0;i<n;i+=8){__m256 v=_mm256_loadu_ps(a+i);
        __m256 k=_mm256_cmp_ps(v,t,_CMP_GT_OQ); s=_mm256_add_ps(s,_mm256_and_ps(v,k));}
    return hsum256(s);
}
// emulacja maski 16-bitowej: 2 x cmp -> 2 x movemask -> sklejenie -> 2 x maskload/maskstore
// (UPPER: unikamy maskload, uzywamy blend + popcount-lite, i tak placimy za 16-bit mask)
__attribute__((noinline)) float B_e(const float*a,int n,float thr){
    __m256 t=_mm256_set1_ps(thr), s=_mm256_setzero_ps();
    for(int i=0;i<n;i+=16){
        v512 v; v.lo=_mm256_loadu_ps(a+i); v.hi=_mm256_loadu_ps(a+i+8);
        __m256 klo=_mm256_cmp_ps(v.lo,t,_CMP_GT_OQ);
        __m256 khi=_mm256_cmp_ps(v.hi,t,_CMP_GT_OQ);
        uint32_t m = (uint32_t)_mm256_movemask_ps(klo) | ((uint32_t)_mm256_movemask_ps(khi)<<8);
        __m256 mlo=_mm256_castsi256_ps(_mm256_setr_epi32(m&1? -1:0,(m>>1)&1? -1:0,(m>>2)&1? -1:0,(m>>3)&1? -1:0,
                    (m>>4)&1? -1:0,(m>>5)&1? -1:0,(m>>6)&1? -1:0,(m>>7)&1? -1:0));
        __m256 mhi=_mm256_castsi256_ps(_mm256_setr_epi32((m>>8)&1? -1:0,(m>>9)&1? -1:0,(m>>10)&1? -1:0,(m>>11)&1? -1:0,
                    (m>>12)&1? -1:0,(m>>13)&1? -1:0,(m>>14)&1? -1:0,(m>>15)&1? -1:0));
        s=_mm256_add_ps(s,_mm256_and_ps(v.lo,mlo));
        s=_mm256_add_ps(s,_mm256_and_ps(v.hi,mhi));
    }
    return hsum256(s);
}

int main(void){
    uint64_t sd=99; const int IT=4000000, NB=8192;
    float*a=aligned_alloc(64,sizeof(float)*512);
    for(int i=0;i<512;i++)a[i]=(rng(&sd)%100)/100.0f;
    float*b=aligned_alloc(64,sizeof(float)*NB);
    for(int i=0;i<NB;i++)b[i]=((int)(rng(&sd)%2000)-1000)/1000.0f;
    volatile float sink; double t;
    sink=A_w(a,IT/10); sink=A_e(a,IT/10); sink=B_w(b,NB,0.2f); sink=B_e(b,NB,0.2f);
    for(int r=0;r<2;r++){
        t=now(); sink=A_w(a,IT); double tw=now()-t;
        t=now(); sink=A_e(a,IT); double te=now()-t;
        t=now(); for(int k=0;k<30000;k++) sink=B_w(b,NB,0.2f); double bw=now()-t;
        t=now(); for(int k=0;k<30000;k++) sink=B_e(b,NB,0.2f); double be=now()-t;
        printf("FMA     : native256 %7.2f ms | emul.512 %7.2f ms | kara %+.0f%%\n",tw*1e3,te*1e3,(te/tw-1)*100);
        printf("maski   : native256 %7.2f ms | emul.512 %7.2f ms | kara %+.0f%%\n",bw*1e3,be*1e3,(be/bw-1)*100);
    }
    return 0;
}
