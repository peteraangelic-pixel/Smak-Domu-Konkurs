// Benchmark: co realnie daje AVX-512 vs AVX2/FMA na tym samym sprzęcie.
// Ten sam kod, kompilowany dwa razy (auto-wektoryzacja przez -march).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>

static double now(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static inline uint64_t rng(uint64_t *s) { *s ^= *s << 13; *s ^= *s >> 7; *s ^= *s << 17; return *s; }

// ---- 1. KERNEL "COMPUTE BOUND": praca w L1/L2, dużo FMA, brak ruchu pamięci globalnej
// typowy dla DSP / macierzy blokowej / symulacji
__attribute__((noinline))
double k_compute(const float *a, float *out, int n, int reps) {
    float acc[16];
    for (int i = 0; i < 16; i++) acc[i] = out[i];
    for (int r = 0; r < reps; r++) {
        for (int i = 0; i < 16; i++) {
            float x = a[i];
            // 8 niezależnych łańcuchów FMA -> maksymalny ILP
            acc[0]  = acc[0]  * 1.0000001f + x;
            acc[1]  = acc[1]  * 1.0000001f + x;
            acc[2]  = acc[2]  * 1.0000001f + x;
            acc[3]  = acc[3]  * 1.0000001f + x;
            acc[4]  = acc[4]  * 1.0000001f + x;
            acc[5]  = acc[5]  * 1.0000001f + x;
            acc[6]  = acc[6]  * 1.0000001f + x;
            acc[7]  = acc[7]  * 1.0000001f + x;
            acc[8]  = acc[8]  * 1.0000001f + x;
            acc[9]  = acc[9]  * 1.0000001f + x;
            acc[10] = acc[10] * 1.0000001f + x;
            acc[11] = acc[11] * 1.0000001f + x;
            acc[12] = acc[12] * 1.0000001f + x;
            acc[13] = acc[13] * 1.0000001f + x;
            acc[14] = acc[14] * 1.0000001f + x;
            acc[15] = acc[15] * 1.0000001f + x;
        }
    }
    double s = 0;
    for (int i = 0; i < 16; i++) { out[i] = acc[i]; s += acc[i]; }
    return s;
}

// ---- 2. KERNEL "MEMORY BOUND": strumieniowy, duże tablice (poza L3)
__attribute__((noinline))
void k_stream(const float *a, const float *b, float *c, size_t n) {
    for (size_t i = 0; i < n; i++) c[i] = a[i] * 1.5f + b[i];
}

// ---- 3. KERNEL "MASKED": redukcja z ogonkiem / warunkowe przetwarzanie
// AVX-512 robi to sprzętowo maskami, AVX2 musi robić blend + tail loop
__attribute__((noinline))
double k_masked(const float *a, int n) {
    double s = 0;
    for (int i = 0; i < n; i++) if (a[i] > 0.0f) s += a[i];
    return s;
}

int main(void) {
    uint64_t seed = 88172645463325252ULL;
    const int REPS = 4000000;
    const int NCOMP = 4096;
    const size_t NSTREAM = 64u * 1024 * 1024; // 64M float = 256 MB x3

    float *a = aligned_alloc(64, sizeof(float) * 16);
    float *out = aligned_alloc(64, sizeof(float) * 16);
    float *c1 = aligned_alloc(64, sizeof(float) * NCOMP);
    for (int i = 0; i < 16; i++) { a[i] = (rng(&seed) % 1000) / 1000.0f; out[i] = 0.1f; }
    for (int i = 0; i < NCOMP; i++) c1[i] = (rng(&seed) % 2000 - 1000) / 1000.0f;

    float *sa = aligned_alloc(64, sizeof(float) * NSTREAM);
    float *sb = aligned_alloc(64, sizeof(float) * NSTREAM);
    float *sc = aligned_alloc(64, sizeof(float) * NSTREAM);
    for (size_t i = 0; i < NSTREAM; i++) { sa[i] = i * 1e-7f; sb[i] = 2.0f; }

    volatile double sink = 0;
    double t;

    // warmup
    sink += k_compute(a, out, 16, 1000);
    sink += k_masked(c1, NCOMP);
    k_stream(sa, sb, sc, 1 << 20);

    // 1
    t = now(); sink += k_compute(a, out, 16, REPS);      double t_comp = now() - t;
    // 2
    t = now(); k_stream(sa, sb, sc, NSTREAM);            double t_str  = now() - t;
    // 3
    t = now();
    for (int r = 0; r < 20000; r++) sink += k_masked(c1, NCOMP);
    double t_mask = now() - t;

    printf("compute_bound_L1   : %8.3f ms  (%s)\n", t_comp * 1e3, "FMA, dane w L1");
    printf("memory_bound_stream: %8.3f ms  (%.1f GB/s efektywnie x3)\n", t_str * 1e3,
           3.0 * NSTREAM * sizeof(float) / t_str / 1e9);
    printf("masked_reduction   : %8.3f ms  (%s)\n", t_mask * 1e3, "warunkowa redukcja");
    (void)sink;
    return 0;
}
