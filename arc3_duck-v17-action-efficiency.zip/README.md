# Gałąź: `arena/duck-v17-action-efficiency`

Punkt wejścia dla innych sesji. Data: **2026-10-30**. Autor: sesja Arena.ai.

## Co nowego na tej gałęzi

| ścieżka | zawartość |
|---|---|
| `ARC3/duck-v17-action-efficiency/` | **warstwa action-efficiency** + pomiar RHAE + raport (`STATUS.md` czytać pierwsze) |
| `ARC3/REVIEWS/2026-10-30-audyt-galezi-i-duck-v17.md` | audyt gałęzi (Smak-Domu, Pokemon ×5, Gemma ×2) + stan konkursu + rekomendacja |
| `AVX512/` | źródła i raport z pomiarów AVX-512 vs AVX2 (osobny wątek, ortogonalny do konkursu) |
| `PUSH_INSTRUCTIONS.md` | jak to wypchnąć (jeśli czytasz to na dysku, nie na GitHubie) |

## Trzy zdania, które wystarczą

1. Metryka RHAE rośnie **kwadratowo** ze spadkiem liczby akcji na poziom — to jedyna dźwignia,
   jaką ten konkurs daje. Nie ma sensu dokładać warstw bez pomiaru tej liczby.
2. W `duck-v17-action-efficiency/` są trzy mechanizmy (cache planów, guard stanów ustalonych,
   księga budżetu) + **zmierzony** wynik offline: RHAE 3,80 → 40,06, akcje/poziom 1 337 → 233.
3. Paczka jest **ortogonalna** do `duck-v16` (Gemma), `v13.4-unified` i `v15` (a450b00f) —
   można ją nałożyć na dowolną z nich. Nie zastępuje ich.

## Zasady, których ta sesja się trzymała

* Zero twierdzeń bez liczby; każda liczba odtwarzalna lokalnie (`run_eval.py`, `test_layer.py`).
* Wyniki negatywne raportowane równie głośno jak pozytywne (2 z 4 gier przegrane).
* Nic na Kaggle, żadnych GPU-runów, żadnych submisji — tylko kod i pomiar offline.
* Nie pushuję na cudze gałęzie; wszystko ląduje wyłącznie tutaj.
