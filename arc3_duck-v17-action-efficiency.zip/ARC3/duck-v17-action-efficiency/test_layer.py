"""Testy warstwy: sprawdzają że mechanizmy faktycznie działają (a nie są martwym kodem).

Wniosek z audytu repo użytkownika: "testy 6/6 zielone przy martwej funkcji".
Dlatego każdy test sprawdza EFEKT na wspólnym liczniku, nie samo wywołanie.
"""
from action_efficiency_layer import PlanCache, ConvergedGuard, BudgetLedger, state_key


def test_plan_cache_learns_and_replays():
    c = PlanCache()
    frames = [b"s0", b"s1", b"s2", b"s3"]
    actions = [3, 3, 1, 4]
    c.learn_from_episode(frames, actions)
    assert c.get(b"s1") == [3, 1, 4], c.get(b"s1")
    assert c.get(b"s3") == [4]
    assert c.get(b"unknown") is None
    # efekt: trafienie licznika
    before = c.hits
    c.get(b"s2")
    assert c.hits == before + 1


def test_guard_detects_long_loop_beyond_window():
    """Pętla o długości 6 — niewykrywalna okienkiem 'ostatnie 3 akcje'."""
    g = ConvergedGuard(repeat_threshold=3)
    cycle = [b"A", b"B", b"C", b"D", b"E", b"F"]
    fired = False
    for rep in range(4):
        for s in cycle:
            if g.observe(s, progress_token=0):
                fired = True
            g.commit(("act", s))
    assert fired, "guard nie wykrył pętli 6-krokowej"


def test_guard_does_not_fire_on_progress():
    g = ConvergedGuard(repeat_threshold=3)
    for lvl in range(5):
        for step in range(5):
            g.observe(f"state_{lvl}_{step}".encode(), progress_token=lvl)
            g.commit(("act", lvl, step))
    assert g.triggered == 0, f"fałszywy alarm (różne stany): {g.triggered}"

    # a teraz: ten sam stan 3x w obrębie poziomu -> to JEST pętla, alarm ma zadziałać
    g2 = ConvergedGuard(repeat_threshold=3)
    for _ in range(3):
        g2.observe(b"loop_state", progress_token=7)
        g2.commit("x")
    assert g2.triggered >= 1


def test_guard_filter_forces_alternative():
    g = ConvergedGuard(repeat_threshold=1)
    g.observe(b"S", 0)
    g.commit("bad")
    g.observe(b"S", 0)
    out = g.filter(["bad", "good"])
    assert out == ["good"], out


def test_budget_prefers_productive_game():
    led = BudgetLedger(total_actions=1000)
    for _ in range(300):
        led.spend("stuck")
    led.completed("stuck")
    for _ in range(50):
        led.spend("winning")
    led.completed("winning")
    assert led.pick_game(["stuck", "winning"]) == "winning"
    # priorytet: 1/(50+200) > 1/(300+200)
    assert led.priority("winning") > led.priority("stuck")


def test_budget_hard_stop():
    led = BudgetLedger(total_actions=10)
    for _ in range(10):
        led.spend("g")
    assert led.pick_game(["g"]) is None


def test_state_key_stable_and_collision_resistant():
    a = ((1, 2), (3, 4))
    b = ((1, 2), (3, 4))
    c = ((1, 2), (4, 3))
    assert state_key(a) == state_key(b)
    assert state_key(a) != state_key(c)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print(f"  PASS  {f.__name__}")
    print(f"\n{len(fns)}/{len(fns)} testów przeszło")
