# ARC3/duck-v17-action-efficiency — punkt wejścia dla innych sesji

**Autor:** sesja Arena.ai, 2026-10-30. **Status: NIEZWERYFIKOWANE NA GPU, NIEZWERYFIKOWANE NA PRAWDZIWYM GATEWAYU.**
Wszystko poniżej jest offline i odtwarzalne w ~30 s. Traktujcie liczby jak hipotezy do przeliczenia,
nie jak pewniki — zgodnie z zasadą nr 4 z `ARC3/STATUS.md` innej gałęzi ("liczby z cudzych README
traktować jak hipotezy").

---

## 0. Dlaczego to powstało

Audyt gałęzi (Smak-Domu `arena/5ed750ef…`, Pokemon ×5, Gemma ×2) wykazał jedną wspólną cechę:
**dużo warstw, mało pomiaru po metryce konkursowej**. Ta paczka atakuje wyłącznie tę metrykę:

```
level_score = min( (human_actions / ai_actions)² , 1.15 )
game_score  = Σ level_score · level_index / Σ level_index     # poziomy 1..n
total       = średnia po grach                                 # nieukończony poziom = 0
```

Wynik rośnie **kwadratowo** ze spadkiem liczby akcji. Zejście ze 100 → 50 akcji na poziom to nie
+2%, to +300% na tym poziomie. Dlatego każdy patch powinien być oceniany jako
Δ(mediana akcji na ukończony poziom), a nie "czy wygląda lepiej".

---

## 1. Co jest w paczce

| plik | rola |
|---|---|
| `sim.py` | 4 mikro-środowiska + **dokładna metryka RHAE** wg docs.arcprize.org/methodology |
| `agent.py` | `ReactiveAgent` (baseline) i `PlannerAgent` (model przejść + BFS + inferencja celu) |
| `action_efficiency_layer.py` | **warstwa do wpięcia w Duck/Franzen**: `PlanCache`, `ConvergedGuard`, `BudgetLedger`, `HarnessHook` |
| `test_layer.py` | 7 testów; każdy sprawdza EFEKT na liczniku, nie samo wywołanie |
| `run_eval.py` | uruchamia oba agenty na tej samej populacji |
| `results.json` | surowe wyniki (12 seedów) |
| `RAPORT.html` | audyt gałęzi + stan konkursu + pełne zastrzeżenia |

```bash
cd ARC3/duck-v17-action-efficiency
python3 run_eval.py 12     # ~25 s, deterministyczne
python3 test_layer.py      # 7/7
```

---

## 2. Wynik (12 seedów × 4 gry × 3 poziomy, limit 4000 akcji/poziom)

| | RHAE | solved | akcji/poziom |
|---|---|---|---|
| REACTIVE (baseline) | 3,80 | 75% | 1 337 |
| PLANNER | **40,06** | **100%** | **233** |

Per gra: key-door 7,86 → **115,00** (cap) · push-block 1,45 → **45,23** ·
switch-order 0,00 → 0,00 · click-sequence 5,89 → **0,00**.

**Dwie gry przegrywają — to jest ważniejsze niż dwie wygrane.** Planner nie ma reguły
"spróbuj akcji na obiekcie", tylko "wejście na pole". To dokładnie ten sam wzorzec, co
zidentyfikowany w `DISCOVERIES.md` przy Riptide/Hammer: brak jednej reguły zjada całą resztę zysku.

---

## 3. Trzy mechanizmy do wpięcia (bez ruszania modelu)

### 3.1 `PlanCache` — plany wielokrokowe są odtwarzane, nie re-planowane
Z jednego epizodu: każde `(stan → reszta ciągu akcji)` staje się planem.
Oszczędza tokeny **i** akcje decyzyjne. W harnessie Duck odpowiada to "action batching",
ale z pamięcią między epizodami, a nie tylko w obrębie jednego planu.

### 3.2 `ConvergedGuard` — guard na hashu stanu, nie na oknie akcji
Wykrywa powrót do stanu, który już widzieliśmy, przy braku progresu; banuje ostatni wybór na TTL.
**Kluczowa różnica wobec istniejących anti-loop (oscillation/repeated/stale):** łapie pętle
**dłuższe niż okno**. Test `test_guard_detects_long_loop_beyond_window` pokazuje pętlę 6-krokową,
niewidoczną dla "ostatnich 3 akcji". Progres (nowy poziom) czyści licznik.

### 3.3 `BudgetLedger` — jawna polityka zamiast progu eskalacji
```
priority(game) = completed_levels / (actions_used + 200)
pick_game()    = argmax priority, twarde odcięcie przy total
```
Zastępuje magiczne progi (10 / 20 / 45k) polityką. Wasze własne liczby z `ARC3/STATUS.md`:
próg 10 → 154 wstrzyknięcia, **31/32 przedwczesnych**. Czyli 2/3 nudge'y idzie w poziomy,
których i tak nie ukończycie — płacicie akcjami za nic.

### 3.4 Integracja (`HarnessHook`, docstring w pliku)
```python
hook = HarnessHook(total_actions=..., n_games=...)
g    = hook.ledger.pick_game(active_games)        # 3. budżet — decyduje, której grze dać GPU
obs  = gateway.observe(g)
plan = hook.cache.get(obs)                        # 1. cache PRZED modelem
if plan: a = plan[0]
else:
    if hook.guard.observe(obs, gateway.level(g)): # 2. guard PO modelu
        cand = hook.guard.filter(model_candidates(...))
    a = choose(cand)
gateway.act(g, a); hook.ledger.spend(g)
if gateway.level(g) != level_before:
    hook.ledger.completed(g); hook.cache.put(obs, tail_of_actions)
hook.guard.commit(a)
```
Kolejność ma znaczenie: cache **przed** modelem, guard **po** modelu, ledger **nad** wszystkim.

---

## 4. Pułapka, którą złapałem po drodze (warta wpisania do DISCOVERIES)

**Obiekt pod graczem jest zasłonięty kolorem gracza.** Naiwna reguła
"obiekt zniknął z obserwacji → został zebrany" daje **fałszywy postęp**: agent staje na obiekcie,
widzi jego zniknięcie, uznaje progres i natychmiast zawraca — pętla 2-krokowa, nieskończona.
Poprawka: obiekt pod graczem trzymaj jako `pending` i rozstrzygnij dopiero **po odejściu z pola**
(czy nadal go nie ma w obserwacji).

To ten sam gatunek błędu co Wasze "testy 6/6 zielone przy martwej funkcji": obserwacja wygląda
poprawnie, a mechanizm jest martwy.

---

## 5. Czego ta paczka NIE twierdzi

* Mikro-środowiska **nie są** grami ARC-AGI-3 (64×64, sprite'y, animacje, ukryta fizyka).
  RHAE 40,06 **nie oznacza** 40% na leaderboardzie. Mierzy mechanizm, nie transfer.
* Nie było smoke'a z GPU, nie było submitu, nie było pomiaru `a/call` po włączeniu tych mechanizmów.
* Nie ruszam modelu (Qwen3.8-Flash-Next W4A16 + SGLang) ani harnessu Tufa Labs — to nie jest
  wąskie gardło. Wąskim gardłem jest **liczba kroków, na jaką pyta się model**.
* Nie zastępuję `duck-v16` (Gemma) ani `v13.4-unified`/`v15` (a450b00f). Te paczki są
  dalej w linii Duck. Ta jest **ortogonalna** — można ją nałożyć na dowolną z nich.

---

## 6. Najkrótsza droga do użycia

1. `python3 test_layer.py` → musi być 7/7 (jeśli nie, nie ufać niczemu dalej).
2. Wpiąć `HarnessHook` w `llm_policy.py`: `cache.get` przed budową promptu, `guard.observe/filter`
   po sparsowaniu odpowiedzi modelu, `ledger.pick_game` zamiast obecnego harmonogramu.
3. Zmierzyć **przed/po** na tej samej populacji r085: mediana akcji na ukończony poziom.
   Bez tej liczby patch jest niezweryfikowany, tak samo jak każdy wcześniejszy.
4. Dopiero potem smoke na GPU i slot submisji.

**Jedna decyzja, która waży więcej niż cała reszta:** przestać dokładać wersje, zacząć mierzyć
akcje na poziom.
