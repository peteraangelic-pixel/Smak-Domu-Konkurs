# arc3_lab — warstwa action-efficiency dla ARC-AGI-3

Własna, **zmierzona** implementacja tego, co w ARC-AGI-3 daje punkty: mniej akcji do
ukończenia poziomu (metryka RHAE = `(human_actions / ai_actions)²`, cap 1.15, waga = numer poziomu).

## Co tu jest

| plik | co robi |
|---|---|
| `sim.py` | 4 mikro-środowiska interaktywne (key-door, switch-order, sokoban-lite, sekwencja kliknięć) + **dokładna metryka RHAE** wg docs.arcprize.org/methodology |
| `agent.py` | `ReactiveAgent` (baseline: greedy + minimalna pamięć, jak harness LLM bez modelu dynamiki) oraz `PlannerAgent` (model przejść + BFS + inferencja celu + portfolio hipotez porządkowania) |
| `action_efficiency_layer.py` | **gotowa do wpięcia warstwa**: `PlanCache`, `ConvergedGuard`, `BudgetLedger` + `HarnessHook` (docstring pokazuje integrację z Duck/Franzen) |
| `test_layer.py` | 7 testów — każdy sprawdza **efekt na liczniku**, nie samo wywołanie (lekcja: „testy 6/6 zielone przy martwej funkcji”) |
| `run_eval.py` | uruchamia oba agenty na tych samych grach i wypisuje RHAE |

## Uruchomienie

```bash
cd arc3_lab
python3 run_eval.py 12      # 12 seedów, 3 poziomy x 4 gry, limit 4000 akcji/poziom
python3 test_layer.py       # 7/7
```

## Wynik (12 seedów, deterministyczny)

```
                 RHAE    solved   akcji/poziom
REACTIVE          3.80    75.0%        1 337
PLANNER          40.06   100.0%        233        <-- 10,5x mniej akcji
```

Per gra (RHAE): keydoor 7.86 → **115.00** (cap), switchorder 0.00 → 0.00 (!),
pushblock 1.45 → **45.23**, colorclicks 5.89 → 0.00 (!).

## Uczciwe zastrzeżenia

* To **mikro-środowiska**, nie prawdziwe gry ARC-AGI-3. Mierzą mechanizm, nie transfer.
* Na `switchorder` i `colorclicks` planner **przegrywa** z prymitywnym baseline'em —
  brakuje mu reguły „spróbuj akcji na obiekcie, nie tylko wejścia na pole”.
  To pokazuje, gdzie warstwa pęka (patrz RAPORT sekcja o porażkach).
* `RAPORT.html` w katalogu wyżej zawiera pełny audyt gałęzi, stan konkursu i plan.
