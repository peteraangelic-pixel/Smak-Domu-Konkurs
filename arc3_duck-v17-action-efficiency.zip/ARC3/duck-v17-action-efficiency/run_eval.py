"""Uruchomienie labu: RHAE-reactive vs RHAE-planner, na tych samych grach."""
import json
import statistics as st
from sim import GAMES
from agent import ReactiveAgent, PlannerAgent

MAX_ACTIONS = 4000


def run_level(game_cls, level, agent_factory, seed, max_actions=MAX_ACTIONS):
    g = game_cls(seed=seed, level=level)
    ag = agent_factory()
    obs = g.observe()
    ai_actions = 0
    while ai_actions < max_actions:
        a = ag.act(obs)
        obs, done = g.step(a)
        ai_actions += 1
        if done:
            break
    solved = g.done
    human = g.human_actions()
    if not solved:
        return {"solved": False, "ai": ai_actions, "human": human, "level_score": 0.0}
    raw = (human / ai_actions) ** 2
    return {"solved": True, "ai": ai_actions, "human": human,
            "level_score": min(raw, 1.15)}


def game_score(levels):
    """weighted average with 1-indexed level weights; unsolved levels count 0."""
    num = sum(r["level_score"] * (i + 1) for i, r in enumerate(levels))
    den = sum(1 for _ in range(len(levels))) and sum(i + 1 for i in range(len(levels)))
    return num / den


def evaluate(agent_factory, seeds=8, max_actions=MAX_ACTIONS):
    out = {}
    for cls in GAMES:
        per_seed = []
        detail = []
        for s in range(seeds):
            lvls = [run_level(cls, lv, agent_factory, s, max_actions)
                    for lv in range(cls.levels)]
            gs = game_score(lvls)
            per_seed.append(gs)
            detail.append(lvls)
        out[cls.name] = {
            "game_score_mean": round(100 * st.mean(per_seed), 2),
            "game_score_stdev": round(100 * st.pstdev(per_seed), 2),
            "solved_rate": round(sum(1 for d in detail for r in d if r["solved"]) /
                                 sum(len(d) for d in detail), 3),
            "avg_actions_per_level": round(st.mean([r["ai"] for d in detail for r in d]), 1),
            "detail": detail[:3],
        }
    out["TOTAL"] = round(st.mean([out[g.name]["game_score_mean"] for g in GAMES]), 2)
    return out


if __name__ == "__main__":
    import sys
    seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    print(f"seeds={seeds}, max_actions/level={MAX_ACTIONS}\n")
    res = {}
    for label, factory in [("REACTIVE (bez modelu)", lambda: ReactiveAgent(seed=0)),
                           ("PLANNER (model + plan)", lambda: PlannerAgent())]:
        r = evaluate(factory, seeds=seeds)
        res[label] = r
        print(f"=== {label} ===")
        for cls in GAMES:
            d = r[cls.name]
            print(f"  {cls.name:14s} RHAE {d['game_score_mean']:6.2f} ±{d['game_score_stdev']:4.2f}"
                  f"  solved {d['solved_rate']*100:5.1f}%  akcji/poziom {d['avg_actions_per_level']:8.1f}")
        print(f"  {'TOTAL':14s} RHAE {r['TOTAL']:6.2f}\n")
    print(f"RÓŻNICA: {res['PLANNER (model + plan)']['TOTAL'] - res['REACTIVE (bez modelu)']['TOTAL']:+.2f} pkt")
    json.dump(res, open("results.json", "w"), indent=1)
