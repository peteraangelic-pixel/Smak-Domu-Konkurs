"""
ARC-AGI-3-like lab: mikro-środowiska interaktywne + dokładna metryka RHAE.

Cel: zmierzyć OFFLINE, ile daje warstwa "action-efficient" nad podejściem
reaktywnym (reprezentującym harness bez modelu dynamiki).

Metryka wg https://docs.arcprize.org/methodology :
    level_score = min((human_actions / ai_actions)**2, 1.15)
    game_score  = sum(level_score * level_index) / sum(level_index)
    total       = mean(game_score)
"""
import random
from collections import deque

UP, DOWN, LEFT, RIGHT, INTERACT = 0, 1, 2, 3, 4
ACTION_NAMES = ["UP", "DOWN", "LEFT", "RIGHT", "INTERACT"]
DIRS = {UP: (0, -1), DOWN: (0, 1), LEFT: (-1, 0), RIGHT: (1, 0)}  # (x,y): y rośnie w dół


class Game:
    """Bazowa klasa. Świat: siatka W x H, gracz, obiekty, cel."""
    name = "base"
    levels = 1

    def __init__(self, seed=0, level=0):
        self.rng = random.Random(seed * 1000 + level)
        self.level = level
        self.cfg = self._make_level(level)
        self.reset()

    def _make_level(self, level):
        raise NotImplementedError

    def reset(self):
        self.pos = self.cfg["start"]
        self.objects = {k: list(v) for k, v in self.cfg["objects"].items()}
        self.collected = set()
        self.steps = 0
        self.done = False
        self.anim = 0

    # --- obserwacja: pełna siatka kolorów (jak w ARC-AGI-3: obrazy 64x64) ---
    def observe(self):
        W, H = self.cfg["W"], self.cfg["H"]
        g = [[0] * W for _ in range(H)]
        for oid, v in self.objects.items():
            x, y, col = v[0], v[1], v[2]
            if oid in self.collected:
                continue
            g[y][x] = col
        g[self.pos[1]][self.pos[0]] = 9  # gracz
        return tuple(tuple(r) for r in g)

    def _adj(self):
        """Obiekty sąsiadujące 4-spójnie z graczem -> (oid, dist)."""
        out = []
        for oid, v in self.objects.items():
            x, y, col = v[0], v[1], v[2]
            if oid in self.collected:
                continue
            d = abs(x - self.pos[0]) + abs(y - self.pos[1])
            if d <= 1:
                out.append((oid, d))
        return out

    def step(self, a):
        if self.done:
            return self.observe(), True
        self.steps += 1
        self.anim += 1
        if a in DIRS:
            dx, dy = DIRS[a]
            nx, ny = self.pos[0] + dx, self.pos[1] + dy
            if 0 <= nx < self.cfg["W"] and 0 <= ny < self.cfg["H"]:
                blocked = any(
                    v[0] == nx and v[1] == ny and oid not in self.collected and len(v) > 3 and v[3]
                    for oid, v in self.objects.items()
                )
                if not blocked:
                    self.pos = (nx, ny)
        else:
            self._interact()
        self._post()
        return self.observe(), self.done

    def _interact(self):
        pass

    def _post(self):
        pass


# ---------------------------------------------------------------- gry
class KeyDoor(Game):
    """Faza 1: dotknij klucz. Faza 2: wejdź na drzwi. Cel ukryty do fazy 1."""
    name = "keydoor"
    levels = 3

    def _make_level(self, level):
        W = H = 10 + level * 2
        start = (1, 1)
        key = (W - 2, 1)
        door = (W - 2, H - 2)
        return {"W": W, "H": H, "start": start,
                "objects": {"key": [key[0], key[1], 3, False],
                            "door": [door[0], door[1], 5, False]}}

    def _post(self):
        kx, ky, _, _ = self.objects["key"]
        if "key" not in self.collected and (self.pos[0], self.pos[1]) == (kx, ky):
            self.collected.add("key")
        dx, dy, _, _ = self.objects["door"]
        if "key" in self.collected and (self.pos[0], self.pos[1]) == (dx, dy):
            self.done = True

    def human_actions(self):
        # najkrótsza ścieżka: start->klucz->drzwi, x1.3 (czynnik ludzki)
        W, H = self.cfg["W"], self.cfg["H"]
        key = tuple(self.objects["key"][:2])
        door = tuple(self.objects["door"][:2])
        d1 = manhattan(self.cfg["start"], key)
        d2 = manhattan(key, door)
        return int((d1 + d2) * 1.3)


class SwitchOrder(Game):
    """Przejdź po przełącznikach w kolejności ROSNĄCEGO KOLORU (ukryte, ale inferowalne)."""
    name = "switchorder"
    levels = 3

    def _make_level(self, level):
        W = H = 9 + level
        start = (0, 0)
        n = 3 + level
        rng = random.Random(level * 77 + 5)
        cells = [(x, y) for x in range(W) for y in range(H) if (x, y) != start]
        picked = rng.sample(cells, n)
        objs, order = {}, []
        # każdy przełącznik ma UNIKALNY kolor: kolejność = rosnący kod koloru
        # (klasyczny prior ARC: posortuj po widocznej cesze skalarnej)
        for i, (x, y) in enumerate(picked):
            oid = f"s{i}"
            objs[oid] = [x, y, 2 + i, False]
            order.append(oid)
        order = sorted(objs, key=lambda k: objs[k][2])
        self._order = order
        return {"W": W, "H": H, "start": start, "objects": objs, "order": order}

    def reset(self):
        super().reset()
        self._next = 0

    def _post(self):
        if self._next >= len(self._order):
            return
        oid = self._order[self._next]
        ox, oy, _, _ = self.objects[oid]
        if (self.pos[0], self.pos[1]) == (ox, oy):
            self.collected.add(oid)
            self._next += 1
            if self._next >= len(self._order):
                self.done = True

    def human_actions(self):
        pts = [self.cfg["start"]] + [tuple(self.objects[o][:2]) for o in self._order]
        d = sum(manhattan(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        return max(1, int(d * 1.3))


class PushBlock(Game):
    """Sokoban-lite: popchnij klocek na pole docelowe."""
    name = "pushblock"
    levels = 3

    def _make_level(self, level):
        W = 8 + level
        H = 6 + level
        start = (2, 2)
        bx, by = 4, 2
        tx, ty = W - 2, 2
        return {"W": W, "H": H, "start": start,
                "objects": {"block": [bx, by, 4, True], "target": [tx, ty, 6, False]}}

    def step(self, a):
        if self.done:
            return self.observe(), True
        self.steps += 1
        self.anim += 1
        if a in DIRS:
            dx, dy = DIRS[a]
            nx, ny = self.pos[0] + dx, self.pos[1] + dy
            bx, by = self.objects["block"][:2]
            if (nx, ny) == (bx, by):
                px, py = bx + dx, by + dy
                if 0 <= px < self.cfg["W"] and 0 <= py < self.cfg["H"]:
                    self.objects["block"][:2] = [px, py]
                    self.pos = (nx, ny)
            elif 0 <= nx < self.cfg["W"] and 0 <= ny < self.cfg["H"]:
                self.pos = (nx, ny)
        self._post()
        return self.observe(), self.done

    def _post(self):
        if tuple(self.objects["block"][:2]) == tuple(self.objects["target"][:2]):
            self.done = True

    def human_actions(self):
        sx, sy = self.cfg["start"]
        bx, by = self.objects["block"][:2]
        tx, ty = self.objects["target"][:2]
        return max(1, int((manhattan((sx, sy), (bx - 1, by)) + (tx - bx)) * 1.3))


class ColorClicks(Game):
    """INTERACT na obiektach w kolejności rosnącej liczby 'kropek' (ukryta)."""
    name = "colorclicks"
    levels = 3

    def _make_level(self, level):
        W = H = 8 + level
        start = (0, 0)
        n = 3 + level
        rng = random.Random(level * 31 + 11)
        cells = [(x, y) for x in range(W) for y in range(H) if (x, y) != start]
        picked = rng.sample(cells, n)
        objs = {}
        for i, (x, y) in enumerate(picked):
            objs[f"c{i}"] = [x, y, 2 + i % 5, False]
        order = sorted(objs, key=lambda k: objs[k][2])
        return {"W": W, "H": H, "start": start, "objects": objs, "order": order}

    def reset(self):
        super().reset()
        self._next = 0

    def _interact(self):
        near = self._adj()
        if not near:
            return
        oid, _ = min(near, key=lambda t: t[1])
        if self._next < len(self.cfg["order"]) and oid == self.cfg["order"][self._next]:
            self.collected.add(oid)
            self._next += 1
            if self._next >= len(self.cfg["order"]):
                self.done = True

    def human_actions(self):
        pts = [self.cfg["start"]] + [tuple(self.objects[o][:2]) for o in self.cfg["order"]]
        d = sum(manhattan(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        return max(1, int((d + len(self.cfg["order"])) * 1.3))


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


GAMES = [KeyDoor, SwitchOrder, PushBlock, ColorClicks]
