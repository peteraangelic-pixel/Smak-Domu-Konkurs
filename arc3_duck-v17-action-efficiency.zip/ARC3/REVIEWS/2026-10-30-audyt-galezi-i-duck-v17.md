# Audyt gałęzi + propozycja duck-v17 — 2026-10-30

## Metoda

* `git clone --filter=blob:none --sparse` gałęzi `arena/5ed750ef-smak-domu-konkurs`;
  analiza `arc-agi-3/llm-agent/`, `arc-agi-3/kaggle/ops/results/` (r001–r118),
  `arc-agi-3/kaggle/results/` (leaderboard, submissions, PUBLIC_APPROACHES).
* GitHub API: listy gałęzi i nagłówki commitów dla `Pokemon` (8 gałęzi),
  `Gemma-konkurs` (3), `Smak-Domu-Konkurs` (2).
* Źródła zewnętrzne: leaderboard Kaggle ARC-AGI-3, `docs.arcprize.org/methodology`,
  publiczne notatniki (Tufa Labs, D. Franzen, społeczność).

## Stan konkursu (2026-10-30)

| | |
|---|---|
| Final Submission Deadline | **2026-11-02** (4 dni) |
| Entry / Team Merger | 2026-10-26 — minął |
| TOP-1 / 2 / 3 | Yi-Chia Chen **75,56** · Tufa Labs **70,02** · faster machine **58,59** |
| Najlepsza submisja w repo | 26,25 (16.10) · najnowsza 1,18 (29.10) |
| Uczestnicy | 18 568 zgłoszeń / 4 982 drużyny / 63 490 submisji |

**Reguła punktacji:** `level_score = min((human/ai)², 1.15)`, waga = numer poziomu,
nieukończony poziom = 0, total = średnia po grach.

Wniosek: wynik rośnie **kwadratowo** ze spadkiem akcji. To jedyna dźwignia, którą ta metryka daje.

## Co jest mocne w dotychczasowej pracy

1. **Rejestr wyników negatywnych.** "3,6× luka silnika NIE ISTNIEJE (r110 to 27B/vLLM)" —
   obalenie własnej hipotezy własnym pomiarem. Rzadkie i wartościowe.
2. **Wykrycie martwego kodu.** Rodzina v18/v19b: wrapper referencjonował `MIRROR_IDS`,
   `RIPTIDE_ID`, `HAMMER_ID`, `WALL_IDS`, których nie ma w namespace v11; `NameError`
   połykany przez `except Exception: pass` → wszystkie porównania "v18 vs v11" były
   porównaniem v11 z v11.
3. **Lekcja metodologiczna.** "testy 6/6 zielone przy martwej funkcji" — dokładnie ten
   wzorzec przeniosłem do `test_layer.py` (testy sprawdzają efekt na liczniku).
4. **Uczciwe oznaczanie niezweryfikowanego** (brak smoke'a GPU, niezmierzony `plan_commit`).

## Pięć miejsc, gdzie tracone są punkty

| # | Obserwacja | Dowód w repo | Konsekwencja w RHAE |
|---|---|---|---|
| 1 | Funkcja celu ≠ metryka | `value_gate`, `evolve_knobs` optymalizują trafność decyzji | RHAE zależy od akcji/poziom, nie od trafności |
| 2 | Walidacja na replayach, nie na gatewayu | `base_actions_per_level is None` w trybie submisji | patch "działa" offline, znika w submicie |
| 3 | Przedwczesna eskalacja | próg 10 → 154 nudge'y, 31/32 przedwczesnych | 2/3 akcji w poziomy nieosiągalne w budżecie |
| 4 | Wersjonowanie zamiast dźwigni | v13.1→v13.5→duck-v16 w kilka dni przy 23–26 | zmieniają się patche, nie wynik |
| 5 | Hipotezy > pomiary | 43 pozycje negatywne, brak pomiaru akcji/poziom | brak sygnału zwrotnego do optymalizacji |

## Propozycja: duck-v17-action-efficiency (ortogonalna)

Trzy mechanizmy, zero zmian w modelu i harnessie:

* `PlanCache` — odtwarzanie sprawdzonych ciągów akcji (oszczędza tokeny i kroki decyzyjne),
* `ConvergedGuard` — guard na hashu stanu; łapie pętle **dłuższe niż okno** anti-loop,
* `BudgetLedger` — `priority = completed/(actions+200)` zamiast magicznych progów.

Pomiar offline: RHAE 3,80 → **40,06**, akcje/poziom 1 337 → **233** (12 seedów, deterministyczne),
przy **dwóch grach przegranych** — bo brakuje reguły "akcja na obiekcie". To pokazuje kierunek
kolejnego patchu: nie więcej warstw, tylko jedna brakująca reguła.

## Rekomendacja na 4 dni

1. Nie dodawać nowych wersji. Wybrać **jedną** (najlepiej `duck-v16` z Gemma, bo ma 9/9 patchy)
   i nałożyć na nią tę warstwę.
2. Zmierzyć mediana akcji na ukończony poziom **przed/po** na r085.
3. Jeśli Δ > 0 → smoke na GPU → slot submisji. Jeśli Δ ≤ 0 → **nie wysyłać** (dowiezione:
   submity bez poprawy kosztują slot i czas).
4. Nie gonić TOP-1 (75,56). Cel: stabilne >25 zamiast 1,18. Medale od ~rank 19 — nierealne w 4 dni,
   ale wyjście z dna tabeli jest w zasięgu.
