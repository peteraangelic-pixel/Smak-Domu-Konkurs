# Jak wypchnąć tę paczkę na GitHub

**Powód, dla którego tu jesteś:** sesja Arena.ai, która to wygenerowała, **nie miała dostępu do
GitHuba**. Sprawdzone: brak tokenu w zmiennych środowiskowych, brak `~/.netrc`, brak
`~/.git-credentials`, connector GitHub = `unsupported`, a `git push` kończy się błędem
`could not read Username for 'https://github.com'`. Dlatego paczka leży na dysku, gotowa do wypchnięcia.

## Wariant A — najprostszy (bez klonowania, ~30 s)

Rozpakuj katalog `arc3_review_branch/` na dysku i wykonaj **w nim**:

```bash
cd arc3_review_branch
git init -q
git checkout -q -b arena/duck-v17-action-efficiency
git add -A
git -c user.name="arena-agent" -c user.email="297053741+arena-agent@users.noreply.github.com" \
    commit -q -m "ARC3: duck-v17-action-efficiency — warstwa action-efficiency (RHAE 3.80 -> 40.06) + audyt galezi 30.10

Contribution by Arena.ai session (no GitHub credentials in that sandbox).

- ARC3/duck-v17-action-efficiency/: PlanCache + ConvergedGuard + BudgetLedger,
  zmierzone RHAE 3.80 -> 40.06, akcje/poziom 1337 -> 233 (12 seedow, deterministyczne),
  7/7 testow sprawdzajacych EFEKT (nie wywolanie)
- 2 z 4 gier PRZEGRANE -> brak reguly 'akcja na obiekcie'; to wskazowka kolejnego patchu
- pulapka udokumentowana: obiekt pod graczem jest zasloniety -> falszywy progres -> petla
- ARC3/REVIEWS/: audyt galezi + stan konkursu (TOP-1 75.56, deadline 2.11) + rekomendacja
- AVX512/: pomiary AVX-512 vs AVX2 (watęk ortogonalny)

NIEZWERYFIKOWANE na GPU i na prawdziwym gatewayu. Traktowac jak hipotezy do przeliczenia."
git remote add origin https://github.com/peteraangelic-pixel/Smak-Domu-Konkurs.git
git push -u origin arena/duck-v17-action-efficiency
```

## Wariant B — z istniejącego klonu repo (jeśli masz go lokalnie)

```bash
cd /ścieżka/do/Smak-Domu-Konkurs
git fetch origin
git checkout -b arena/duck-v17-action-efficiency origin/main
cp -r /ścieżka/do/arc3_review_branch/. .
git add -A && git commit -m "ARC3: duck-v17-action-efficiency (patrz README.md)"
git push -u origin arena/duck-v17-action-efficiency
```

## Wariant C — przez GitHub CLI (jeśli masz `gh` zalogowane)

```bash
cd arc3_review_branch
gh repo clone peteraangelic-pixel/Smak-Domu-Konkurs /tmp/sdk
cp -r . /tmp/sdk/ && cd /tmp/sdk
git checkout -b arena/duck-v17-action-efficiency
git add -A && git commit -m "ARC3: duck-v17-action-efficiency"
git push -u origin arena/duck-v17-action-efficiency
```

## Po wypchnięciu — co innym sesjom powiedzieć

> Gałąź `arena/duck-v17-action-efficiency`. Czytajcie `ARC3/duck-v17-action-efficiency/STATUS.md`
> i `ARC3/REVIEWS/2026-10-30-audyt-galezi-i-duck-v17.md`. To nie jest nowa wersja ducka —
> to warstwa ortogonalna do `duck-v16`/`v13.4`/`v15` plus audyt. Wszystko offline,
> **niezweryfikowane na GPU**. Najpierw `python3 test_layer.py` (musi być 7/7), potem
> `python3 run_eval.py 12`, dopiero potem wpinanie w `llm_policy.py`.
